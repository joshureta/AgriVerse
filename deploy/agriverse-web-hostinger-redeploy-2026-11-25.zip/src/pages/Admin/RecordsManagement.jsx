import { useEffect, useMemo, useRef, useState } from 'react'
import { ChevronDown, Eye, FileDown, FileText, Search, X } from 'lucide-react'
import { AdminSidebar, AdminTopbar } from '../../components/AdminNavigation.jsx'
import Pagination from '../../components/Pagination.jsx'
import { supabase } from '../../lib/supabase.js'
import { downloadDashboardReportPdf } from '../../lib/dashboardReportPdf.js'
import { buildFarmRecordsReport } from '../../lib/farmRecordsReport.js'
import '../../styles/admin-dashboard.css'
import '../../styles/task-schedule-management.css'
import '../../styles/records-management.css'

const API_URL = (import.meta.env.VITE_API_URL || 'http://localhost:5000').replace(/\/$/, '')
const PAGE_SIZE = 10
const EXPORT_PAGE_SIZE = 200
const SEARCH_DELAY_MS = 300

// Gets an access token for admin requests.
async function readAccessToken(refresh = false) {
  const result = refresh ? await supabase.auth.refreshSession() : await supabase.auth.getSession()
  if (result.error) throw new Error(result.error.message)
  const token = result.data.session?.access_token
  if (!token) throw new Error('Your session has ended. Please sign in again.')
  return token
}

// Sends an authenticated request to the admin API.
async function apiRequest(path, options = {}, retry = true) {
  const token = await readAccessToken()
  const controller = new AbortController()
  const timeout = window.setTimeout(() => controller.abort(), 12000)
  try {
    const response = await fetch(`${API_URL}${path}`, {
      ...options,
      signal: controller.signal,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}`, ...options.headers },
    })
    if (response.status === 401 && retry) {
      await readAccessToken(true)
      return apiRequest(path, options, false)
    }
    const body = await response.json().catch(() => ({}))
    if (!response.ok) throw new Error(body?.error || `Request failed (${response.status})`)
    return body
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('Records are temporarily unavailable. Please try again.')
    throw error
  } finally {
    window.clearTimeout(timeout)
  }
}

// Identifies the records requested for the current view.
function requestKeyOf(categoryId, search, page, activity) {
  return `${categoryId}|${search}|${page}|${activity}`
}

// Builds the API path for a page of records.
function recordsPath({ categoryId, search, page, pageSize, activity }) {
  const params = new URLSearchParams({ category_id: String(categoryId), search, page: String(page), pageSize: String(pageSize) })
  if (activity) params.set('activity_type', activity)
  return `/api/admin/tasks/records?${params}`
}

// A report needs every matching record, not just the visible page, so walk all pages.
async function loadAllRecordTasks(categoryId, search, activity) {
  const tasks = []
  let page = 1
  let totalPages = 1
  do {
    const data = await apiRequest(recordsPath({ categoryId, search, page, pageSize: EXPORT_PAGE_SIZE, activity }))
    tasks.push(...(Array.isArray(data.tasks) ? data.tasks : []))
    totalPages = data.pagination?.totalPages || 1
    page += 1
  } while (page <= totalPages)
  return tasks
}

// Formats a record date and time.
function formatDate(value) {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return '—'
  return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }).format(date)
}

// Formats a delivery's scheduled time window.
function formatDeliveryWindow(start, end) {
  if (!start || !end) return 'Schedule pending'
  const formatter = new Intl.DateTimeFormat('en-PH', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })
  const timeFormatter = new Intl.DateTimeFormat('en-PH', { hour: 'numeric', minute: '2-digit' })
  return `${formatter.format(new Date(start))} – ${timeFormatter.format(new Date(end))}`
}

// Shows an insight or a fallback when it is empty.
function insightText(value, empty = '—') {
  return String(value ?? '').trim() || empty
}

// Displays a link to a record's proof photo.
function ProofPhoto({ url, alt }) {
  if (!url) return <p>No photo proof was attached.</p>
  return (
    <a className="records-proof" href={url} target="_blank" rel="noreferrer" aria-label={`Open ${alt} full size`}>
      <img src={url} alt={alt} loading="lazy" />
    </a>
  )
}

// Displays the heading and close button for a record dialog.
function TaskModalHeader({ title, onClose, tag = 'Farm Records' }) {
  return (
    <header className="task-dialog-header">
      <div>
        <p>{tag}</p>
        <h2>{title}</h2>
      </div>
      {onClose && (
        <button className="task-modal-header-close" type="button" onClick={onClose} aria-label="Close">
          <X size={18} aria-hidden="true" />
        </button>
      )}
    </header>
  )
}

// Real harvest counts, reported by the worker and approved by admin (worker-tasks.js / admin-tasks.js).
function harvestCounts(task) {
  // Shows a dash when a harvest count is missing.
  const orDash = (value) => (value === null || value === undefined ? '—' : value)
  return {
    small: orDash(task.harvest_small_count),
    medium: orDash(task.harvest_medium_count),
    large: orDash(task.harvest_large_count),
    damaged: orDash(task.harvest_damaged_count),
  }
}

// What the worker entered: inspection answers on completion, supplies taken when the task started.
function detailText(task, key) { return task.details?.[key] || '—' }
// Gets the supply item used for a task.
function suppliesName(task) { return task.inventory_item?.item_name || '—' }
// Formats the amount of supplies used.
function suppliesAmount(task) {
  if (!task.inventory_quantity) return '—'
  return `${task.inventory_quantity} ${task.inventory_item?.unit?.abbreviation || ''}`.trim()
}

// Chooses the record layout for a task category.
function categoryKind(categoryName, activityType) {
  const key = String(categoryName || '').trim().toLowerCase()
  if (key === 'planting') return 'planting'
  if (key === 'fertilization') return 'fertilization'
  if (key === 'irrigation') return 'irrigation'
  if (key === 'monitoring') return 'inspection'
  if (key === 'pest & disease') return activityType === 'action' ? 'pestaction' : 'inspection'
  if (key === 'harvesting') return 'harvesting'
  if (key === 'weeding') return 'weeding'
  if (key === 'stock check') return 'stockcheck'
  return 'generic'
}

// Totals of an approved Stock Check, sent by the records API as stock_check_summary.
function stockCheckTotals(task) {
  const summary = task.stock_check_summary
  const orDash = (value) => (summary ? value : '—')
  return {
    counted: orDash(`${summary?.counted} pcs`),
    good: orDash(`${summary?.good} pcs`),
    nonSaleable: orDash(`${summary?.non_saleable} pcs`),
    unaccounted: orDash(`${summary?.unaccounted} pcs`),
    writtenOff: orDash(summary?.written_off < 0 ? `+${-summary.written_off} pcs` : `${summary?.written_off} pcs`),
  }
}

// Builds a table row from a completed task.
function recordRow(task, kind) {
  const worker = task.assigned_worker?.full_name || 'Unassigned worker'
  const date = formatDate(task.completed_at)
  const insight = insightText(task.completion_notes)
  if (kind === 'planting') return [task.field, worker, date, insight]
  if (kind === 'fertilization') return [task.field, worker, date, suppliesName(task), suppliesAmount(task), insight]
  if (kind === 'irrigation') return [task.field, worker, date, insight]
  if (kind === 'inspection') return [task.field, worker, date, detailText(task, 'crop_condition'), detailText(task, 'pest_observed'), detailText(task, 'recommended_action'), insight]
  if (kind === 'pestaction') return [task.field, worker, date, suppliesName(task), suppliesAmount(task), insight]
  if (kind === 'harvesting') { const sizes = harvestCounts(task); return [task.field, worker, date, sizes.small, sizes.medium, sizes.large, sizes.damaged, insight] }
  if (kind === 'weeding') return [task.field, worker, date, insight]
  if (kind === 'stockcheck') return [task.field, worker, date, stockCheckTotals(task).removed, insight]
  return [task.field, worker, formatDate(task.started_at), date, insight]
}

const RECORD_COLUMNS = {
  planting: ['FIELD', 'FARM WORKER', 'PLANTING DATE', 'INSIGHTS', 'ACTIONS'],
  fertilization: ['FIELD', 'FARM WORKER', 'APPLICATION DATE', 'FERTILIZER', 'AMOUNT USED', 'INSIGHTS', 'ACTIONS'],
  irrigation: ['FIELD', 'FARM WORKER', 'DATE & TIME', 'INSIGHTS', 'ACTIONS'],
  inspection: ['FIELD', 'ASSIGNED INSPECTOR', 'INSPECTION DATE', 'CROP CONDITION', 'PEST/DISEASE OBSERVED', 'RECOMMENDED ACTION', 'INSIGHTS', 'ACTIONS'],
  pestaction: ['FIELD', 'FARM WORKER', 'ACTION DATE', 'PESTICIDE', 'AMOUNT USED', 'INSIGHTS', 'ACTIONS'],
  harvesting: ['FIELD', 'FARM WORKER', 'HARVEST DATE', 'SMALL', 'MEDIUM', 'LARGE', 'DAMAGED', 'INSIGHTS', 'ACTIONS'],
  weeding: ['FIELD', 'FARM WORKER', 'DATE & TIME', 'INSIGHTS', 'ACTIONS'],
  stockcheck: ['LOCATION', 'CONDUCTED BY', 'CHECK DATE', 'DAMAGED REMOVED', 'INSIGHTS', 'ACTIONS'],
  generic: ['FIELD', 'FARM WORKER', 'DATE STARTED', 'DATE COMPLETED', 'INSIGHTS', 'ACTIONS'],
}

// Generates a PDF for the selected records tab, using the same report layout as the dashboard.
function RecordsReportMenu({ category, categoryId, kind, activity, search, orders, disabled }) {
  const menuRef = useRef(null)
  const [open, setOpen] = useState(false)
  const [period, setPeriod] = useState('month')
  const [generating, setGenerating] = useState(false)
  const [error, setError] = useState('')

  // Attaches outside-click and Escape handlers while the report menu is open.
  useEffect(() => {
    if (!open) return undefined
    // Closes the report menu when a pointer event lands outside it.
    const closeOutside = (event) => { if (!menuRef.current?.contains(event.target)) setOpen(false) }
    // Closes the report menu when Escape is pressed.
    const closeEscape = (event) => { if (event.key === 'Escape') setOpen(false) }
    document.addEventListener('pointerdown', closeOutside)
    document.addEventListener('keydown', closeEscape)
    return () => {
      document.removeEventListener('pointerdown', closeOutside)
      document.removeEventListener('keydown', closeEscape)
    }
  }, [open])

  // Builds and downloads a PDF for the selected records and period.
  async function generate(event) {
    event.preventDefault()
    setGenerating(true)
    setError('')
    try {
      const tasks = kind === 'delivery' ? [] : await loadAllRecordTasks(categoryId, search.trim(), activity)
      const report = buildFarmRecordsReport({ tasks, orders, category, kind, period, search: search.trim() })
      await downloadDashboardReportPdf(report)
      setOpen(false)
    } catch (requestError) {
      setError(requestError.message || 'Unable to generate the PDF report.')
    } finally {
      setGenerating(false)
    }
  }

  return <div className="dashboard-report-menu records-report-menu" ref={menuRef}>
    <button type="button" className="dashboard-report-trigger" disabled={disabled || generating}
      aria-haspopup="dialog" aria-expanded={open} aria-controls="records-report-popover"
      onClick={() => { setOpen((value) => !value); setError('') }}>
      <span className="dashboard-report-trigger-main"><FileText size={17} aria-hidden="true" /> Generate Report</span>
      <ChevronDown size={16} aria-hidden="true" />
    </button>
    {open && <section className="dashboard-report-popover" id="records-report-popover" role="dialog" aria-label={`Generate ${category} report`}>
      <form onSubmit={generate}>
        <select id="records-report-period" aria-label="Date range" value={period} onChange={(event) => setPeriod(event.target.value)}>
          <option value="week">This week</option>
          <option value="month">This month</option>
          <option value="year">This year</option>
          <option value="all">All time</option>
        </select>
        {error && <p className="dashboard-report-error" role="alert">{error}</p>}
        <button className="dashboard-report-submit" type="submit" disabled={generating}>
          <FileDown size={16} aria-hidden="true" /> {generating ? 'Generating…' : 'Generate PDF'}
        </button>
      </form>
    </section>}
  </div>
}

// Displays completed task and delivery records.
export default function RecordsManagement() {
  const [categories, setCategories] = useState([])
  const [activeCategory, setActiveCategory] = useState('')
  const [activityTab, setActivityTab] = useState('inspection')
  const [optionsState, setOptionsState] = useState({ loaded: false, error: '' })
  const [result, setResult] = useState({ key: '', tasks: [], total: 0, pages: 1, error: '' })
  const [deliveryOrders, setDeliveryOrders] = useState([])
  const [deliveryLoading, setDeliveryLoading] = useState(true)
  const [deliveryError, setDeliveryError] = useState('')
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [page, setPage] = useState(1)
  const [modal, setModal] = useState(null)

  const isDeliveryTab = activeCategory === 'delivery'
  // Finds the label for the selected record category.
  const activeCategoryName = useMemo(
    () => categories.find((category) => String(category.id) === String(activeCategory))?.category_name || '',
    [categories, activeCategory],
  )
  // Pest & Disease splits into Inspection and Action records, each with its own columns.
  const isPestAndDiseaseTab = activeCategoryName === 'Pest & Disease'
  const activityFilter = isPestAndDiseaseTab ? activityTab : ''
  // The loaded page is only valid for the category, search, and page it was requested with.
  const requestKey = requestKeyOf(activeCategory, debouncedSearch, page, activityFilter)

  // Loads the task categories used by the records tabs.
  useEffect(() => {
    let cancelled = false
    apiRequest('/api/admin/tasks/options')
      .then((data) => {
        if (cancelled) return
        const allCategories = Array.isArray(data.categories) ? data.categories : []
        setCategories(allCategories)
        setActiveCategory((current) => current === '' && allCategories.length ? allCategories[0].id : current)
        setOptionsState({ loaded: true, error: '' })
      })
      .catch((requestError) => { if (!cancelled) setOptionsState({ loaded: true, error: requestError.message }) })
    return () => { cancelled = true }
  }, [])

  // Loads assigned delivery records.
  useEffect(() => {
    let cancelled = false
    apiRequest('/api/admin/deliveries/assigned-orders')
      .then((data) => { if (!cancelled) setDeliveryOrders(Array.isArray(data.orders) ? data.orders : []) })
      .catch((requestError) => { if (!cancelled) setDeliveryError(requestError.message) })
      .finally(() => { if (!cancelled) setDeliveryLoading(false) })
    return () => { cancelled = true }
  }, [])

  // Delays searching until the user pauses typing.
  useEffect(() => {
    const timer = window.setTimeout(() => setDebouncedSearch(search.trim()), SEARCH_DELAY_MS)
    return () => window.clearTimeout(timer)
  }, [search])

  // Loads the matching page of completed task records.
  useEffect(() => {
    if (isDeliveryTab || activeCategory === '') return undefined
    let cancelled = false
    const key = requestKeyOf(activeCategory, debouncedSearch, page, activityFilter)
    apiRequest(recordsPath({ categoryId: activeCategory, search: debouncedSearch, page, pageSize: PAGE_SIZE, activity: activityFilter }))
      .then((data) => {
        if (cancelled) return
        const total = data.pagination?.total || 0
        const pages = data.pagination?.totalPages || 1
        // The page no longer exists (records were removed), so step back to the last one.
        if (page > 1 && total > 0 && page > pages) {
          setPage(pages)
          return
        }
        setResult({ key, tasks: Array.isArray(data.tasks) ? data.tasks : [], total, pages, error: '' })
      })
      .catch((requestError) => { if (!cancelled) setResult({ key, tasks: [], total: 0, pages: 1, error: requestError.message }) })
    return () => { cancelled = true }
  }, [activeCategory, debouncedSearch, page, activityFilter, isDeliveryTab])

  // Switches the record category and resets the page.
  function selectCategory(id) {
    setActiveCategory(id)
    setPage(1)
  }

  // Switches the activity type and resets the page.
  function selectActivity(value) {
    setActivityTab(value)
    setPage(1)
  }

  // Updates the search text and returns to the first page.
  function changeSearch(value) {
    setSearch(value)
    setPage(1)
  }

  const taskLoading = activeCategory === '' ? !optionsState.loaded : result.key !== requestKey
  const loading = isDeliveryTab ? deliveryLoading : taskLoading
  const error = isDeliveryTab ? deliveryError : (optionsState.error || (taskLoading ? '' : result.error))

  // Filters and sorts delivery records for the current view.
  const filteredDeliveries = useMemo(() => {
    if (!isDeliveryTab) return []
    const term = search.trim().toLowerCase()
    return deliveryOrders
      .filter((order) => !term || `${order.order_number} ${order.assigned_driver?.full_name || ''} ${order.delivery_full_name || ''}`.toLowerCase().includes(term))
      .sort((first, second) => new Date(second.delivery_scheduled_at || 0) - new Date(first.delivery_scheduled_at || 0))
  }, [deliveryOrders, search, isDeliveryTab])

  const recordCount = isDeliveryTab ? filteredDeliveries.length : result.total
  const totalPages = isDeliveryTab ? Math.max(1, Math.ceil(filteredDeliveries.length / PAGE_SIZE)) : result.pages
  const paginated = isDeliveryTab ? filteredDeliveries.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE) : result.tasks

  const kind = activeCategory === '' ? 'generic' : categoryKind(activeCategoryName, activityFilter)
  const columns = RECORD_COLUMNS[kind]
  const firstVisibleRecord = recordCount ? (page - 1) * PAGE_SIZE + 1 : 0
  const lastVisibleRecord = Math.min(page * PAGE_SIZE, recordCount)

  return (
    <main className="admin-dashboard task-schedule-page records-page">
      {/* Admin navigation and page header. */}
      <AdminSidebar active="records" />
      <section className="admin-workspace">
        <AdminTopbar />
        <div className="task-schedule-content records-content">
          {/* Page title and report action. */}
          <header className="task-page-heading records-page-heading">
            <div>
              <h1>Farm Records</h1>
              <p>Review farm activities and delivery history in one place.</p>
            </div>
            <RecordsReportMenu key={`${activeCategory}-${activityFilter}`}
              category={isDeliveryTab ? 'Delivery' : isPestAndDiseaseTab ? `Pest & Disease ${activityTab === 'action' ? 'Action' : 'Inspection'}` : activeCategoryName || 'Farm Records'}
              categoryId={activeCategory} kind={isDeliveryTab ? 'delivery' : kind} activity={activityFilter}
              search={search} orders={filteredDeliveries} disabled={loading || Boolean(error)} />
          </header>

          {/* Category tabs, search, and record table. */}
          <section className="tasks-panel records-panel">
            <div className="records-category-section">
              <nav className="task-management-tabs records-tabs" aria-label="Record category">
                {categories.map((category) => (
                  <button
                    className={String(activeCategory) === String(category.id) ? 'is-active' : ''}
                    type="button"
                    key={category.id}
                    onClick={() => selectCategory(category.id)}
                  >
                    {category.category_name}
                  </button>
                ))}
                <button className={isDeliveryTab ? 'is-active' : ''} type="button" onClick={() => selectCategory('delivery')}>Delivery</button>
              </nav>
              {isPestAndDiseaseTab && (
                <div className="records-subtabs" role="tablist" aria-label="Pest and disease activity">
                  {[['inspection', 'Inspection'], ['action', 'Action']].map(([value, label]) => (
                    <button type="button" role="tab" aria-selected={activityTab === value} className={activityTab === value ? 'is-active' : ''} key={value} onClick={() => selectActivity(value)}>{label}</button>
                  ))}
                </div>
              )}
            </div>

            <div className="tasks-toolbar records-toolbar">
              <label className="task-search records-search">
                <Search aria-hidden="true" size={17} />
                <span className="sr-only">Search records</span>
                <input type="search" value={search} onChange={(event) => changeSearch(event.target.value)} placeholder="Search field, worker, order, or customer…" />
                {search && <button type="button" onClick={() => changeSearch('')} aria-label="Clear search"><X aria-hidden="true" size={15} /></button>}
              </label>
            </div>

            {error && <div className="tasks-error" role="alert">{error}</div>}
            <div className="tasks-table-wrap">
              <table className="tasks-table" style={{ tableLayout: 'auto' }}>
                <thead>
                  {isDeliveryTab
                    ? <tr><th>DRIVER</th><th>ORDER NUMBER</th><th>CUSTOMER</th><th>DELIVERY ADDRESS</th><th>DELIVERY WINDOW</th><th>STATUS</th><th>INSIGHTS</th><th>ACTIONS</th></tr>
                    : <tr>{columns.map((label) => <th key={label}>{label}</th>)}</tr>}
                </thead>
                <tbody>
                  {loading ? <tr><td className="tasks-empty" colSpan={isDeliveryTab ? 8 : columns.length}>Loading records…</td></tr> : <>
                    {!paginated.length && <tr><td className="tasks-empty" colSpan={isDeliveryTab ? 8 : columns.length}>No records found.</td></tr>}
                    {isDeliveryTab
                      ? paginated.map((order) => (
                        <tr key={`delivery-${order.id}`}>
                          <td>{order.assigned_driver?.full_name || 'Unassigned driver'}</td>
                          <td><strong>{order.order_number}</strong></td>
                          <td>{order.delivery_full_name}</td>
                          <td>{[order.delivery_barangay, order.delivery_city_municipality, order.delivery_province, order.delivery_region].filter(Boolean).join(', ')}</td>
                          <td>{formatDeliveryWindow(order.delivery_scheduled_at, order.delivery_window_end_at)}</td>
                          <td><span className={`task-status status-${order.delivery_assignment_status || 'assigned'}`}>{(order.delivery_assignment_status || 'assigned').replaceAll('_', ' ')}</span></td>
                          <td><small className="records-insight" title={insightText(order.delivery_proof_notes, '')}>{insightText(order.delivery_proof_notes)}</small></td>
                          <td><div className="task-actions"><button className="task-view" type="button" onClick={() => setModal({ mode: 'view-delivery', order })} aria-label={`View delivery ${order.order_number}`}><Eye aria-hidden="true" size={14} /> View</button></div></td>
                        </tr>
                      ))
                      : paginated.map((task) => {
                        const row = recordRow(task, kind)
                        return (
                          <tr key={`task-${task.id}`}>
                            {row.map((cell, index) => <td key={index}>{index === row.length - 1 ? <small className="records-insight" title={cell === '—' ? undefined : cell}>{cell}</small> : cell}</td>)}
                            <td><div className="task-actions"><button className="task-view" type="button" onClick={() => setModal({ mode: 'view-task', task, kind })} aria-label={`View ${kind} record`}><Eye aria-hidden="true" size={14} /> View</button></div></td>
                          </tr>
                        )
                      })}
                  </>}
                </tbody>
              </table>
            </div>

            <footer className="pagination-footer">
              <span>Showing {firstVisibleRecord}–{lastVisibleRecord} of {recordCount}</span>
              <Pagination page={page} totalPages={totalPages} onChange={setPage} disabled={loading} ariaLabel="Record pages" />
            </footer>
          </section>
        </div>
      </section>

      {/* Completed task details dialog. */}
      {modal?.mode === 'view-task' && <div className="task-modal-backdrop">
        <section className="task-reference-modal view-task-modal" role="dialog" aria-modal="true" aria-labelledby="view-record-title">
          <TaskModalHeader title="View Record" onClose={() => setModal(null)} />
          <div className="task-reference-body task-view-body">
            <div className="task-view-grid">
              <div className="task-view-tile">
                <span className="task-view-tile-label">Category</span>
                <strong className="task-view-tile-value">{modal.task.category}</strong>
              </div>
              <div className="task-view-tile">
                <span className="task-view-tile-label">Status</span>
                <div>
                  <span className={`task-status-badge status-${modal.task.status}`}>{modal.task.status_label}</span>
                </div>
              </div>
              <div className="task-view-tile">
                <span className="task-view-tile-label">{modal.kind === 'inspection' ? 'Assigned Inspector' : 'Farm Worker'}</span>
                <strong className="task-view-tile-value">{modal.task.assigned_worker?.full_name || 'Unassigned worker'}</strong>
              </div>
              <div className="task-view-tile">
                <span className="task-view-tile-label">Field</span>
                <strong className="task-view-tile-value">{modal.task.field}</strong>
              </div>
              {modal.task.activity_type && <div className="task-view-tile"><span className="task-view-tile-label">Activity</span><strong className="task-view-tile-value">{modal.task.activity_type === 'action' ? 'Action' : 'Inspection'}</strong></div>}
              {modal.kind === 'fertilization' && <><div className="task-view-tile"><span className="task-view-tile-label">Fertilizer</span><strong className="task-view-tile-value">{suppliesName(modal.task)}</strong></div><div className="task-view-tile"><span className="task-view-tile-label">Amount Used</span><strong className="task-view-tile-value">{suppliesAmount(modal.task)}</strong></div></>}
              {modal.kind === 'pestaction' && <><div className="task-view-tile"><span className="task-view-tile-label">Pesticide</span><strong className="task-view-tile-value">{suppliesName(modal.task)}</strong></div><div className="task-view-tile"><span className="task-view-tile-label">Amount Used</span><strong className="task-view-tile-value">{suppliesAmount(modal.task)}</strong></div></>}
              {modal.kind === 'inspection' && <><div className="task-view-tile"><span className="task-view-tile-label">Crop Condition</span><strong className="task-view-tile-value">{detailText(modal.task, 'crop_condition')}</strong></div><div className="task-view-tile"><span className="task-view-tile-label">Pest/Disease Observed</span><strong className="task-view-tile-value">{detailText(modal.task, 'pest_observed')}</strong></div><div className="task-view-tile task-view-tile-full"><span className="task-view-tile-label">Recommended Action</span><strong className="task-view-tile-value">{detailText(modal.task, 'recommended_action')}</strong></div></>}
              {modal.kind === 'stockcheck' && <>
                <div className="task-view-tile"><span className="task-view-tile-label">Damaged Removed</span><strong className="task-view-tile-value">{stockCheckTotals(modal.task).removed}</strong></div>
                {(modal.task.stock_check_summary?.sizes || []).map((size) => (
                  <div className="task-view-tile" key={size.size}>
                    <span className="task-view-tile-label">{size.size}</span>
                    <strong className="task-view-tile-value">{size.removed} pcs</strong>
                  </div>
                ))}
              </>}
              {modal.kind === 'harvesting' && <><div className="task-view-tile"><span className="task-view-tile-label">Small / Medium / Large</span><strong className="task-view-tile-value">{harvestCounts(modal.task).small} / {harvestCounts(modal.task).medium} / {harvestCounts(modal.task).large}</strong></div><div className="task-view-tile"><span className="task-view-tile-label">Damaged</span><strong className="task-view-tile-value">{harvestCounts(modal.task).damaged} damaged</strong></div></>}
              <div className="task-view-tile">
                <span className="task-view-tile-label">Date Started</span>
                <strong className="task-view-tile-value">{formatDate(modal.task.started_at)}</strong>
              </div>
              <div className="task-view-tile">
                <span className="task-view-tile-label">Date Completed</span>
                <strong className="task-view-tile-value">{formatDate(modal.task.completed_at)}</strong>
              </div>
            </div>
            <section className="task-view-description"><span>Insights</span><p>{insightText(modal.task.completion_notes, 'No insights were added.')}</p></section>
            {modal.kind === 'stockcheck'
              ? <section className="task-view-description"><span>Photographic evidence</span><p>The photos and the count for each condition are shown in Task and Schedule, in this task's View dialog.</p></section>
              : <section className="task-view-description"><span>Photo proof</span><ProofPhoto url={modal.task.harvest_proof_image_url || modal.task.completion_proof_image_url} alt="Photo proof of completed work" /></section>}
          </div>
        </section>
      </div>}

      {/* Delivery record details dialog. */}
      {modal?.mode === 'view-delivery' && <div className="task-modal-backdrop">
        <section className="task-reference-modal view-task-modal" role="dialog" aria-modal="true" aria-labelledby="view-delivery-record-title">
          <TaskModalHeader title="View Delivery Record" tag="Delivery records" onClose={() => setModal(null)} />
          <div className="task-reference-body task-view-body">
            <div className="task-view-grid">
              <div className="task-view-tile">
                <span className="task-view-tile-label">Order Number</span>
                <strong className="task-view-tile-value">{modal.order.order_number}</strong>
              </div>
              <div className="task-view-tile">
                <span className="task-view-tile-label">Delivery Status</span>
                <div>
                  <span className={`task-status-badge status-${modal.order.delivery_assignment_status || 'assigned'}`}>{(modal.order.delivery_assignment_status || 'assigned').replaceAll('_', ' ')}</span>
                </div>
              </div>
              <div className="task-view-tile">
                <span className="task-view-tile-label">Driver</span>
                <strong className="task-view-tile-value">{modal.order.assigned_driver?.full_name || 'Unassigned driver'}</strong>
              </div>
              <div className="task-view-tile">
                <span className="task-view-tile-label">Customer</span>
                <strong className="task-view-tile-value">{modal.order.delivery_full_name || 'Not provided'}</strong>
              </div>
              <div className="task-view-tile task-view-tile-full">
                <span className="task-view-tile-label">Delivery Window</span>
                <strong className="task-view-tile-value">{formatDeliveryWindow(modal.order.delivery_scheduled_at, modal.order.delivery_window_end_at)}</strong>
              </div>
            </div>
            <section className="task-view-description"><span>Delivery Address</span><p>{[modal.order.delivery_barangay, modal.order.delivery_city_municipality, modal.order.delivery_province, modal.order.delivery_region].filter(Boolean).join(', ') || 'No delivery address provided.'}</p></section>
            <section className="task-view-description"><span>Insights</span><p>{insightText(modal.order.delivery_proof_notes, 'No insights were added.')}</p></section>
            <section className="task-view-description"><span>Photo proof</span><ProofPhoto url={modal.order.delivery_proof_image_url} alt="Proof of delivery" /></section>
          </div>
        </section>
      </div>}
    </main>
  )
}
