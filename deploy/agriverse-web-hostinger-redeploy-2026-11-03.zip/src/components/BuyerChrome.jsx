import { useEffect, useRef, useState } from 'react'
import {
  Bell,
  CheckCircle2,
  ChevronDown,
  Clock3,
  LogOut,
  Mail,
  Menu,
  MessageCircle,
  PackageCheck,
  Send,
  ShoppingCart,
  Truck,
  UserRound,
} from 'lucide-react'
import { useAuth } from '../hooks/useAuth.js'
import jtoledoLogo from '../assets/Jtoledologo.png'
import { BUYER_NOTIFICATION_READ_EVENT, isBuyerNotificationRead, readBuyerNotificationIds, saveBuyerNotificationIds } from '../lib/buyerNotificationReadState.js'
import { buyerCartQuantity, loadBuyerNotifications, readBuyerCart } from '../services/buyerMarketplace.js'
import { loadBuyerUnreadCount } from '../services/buyerMessages.js'

const UNREAD_POLL_INTERVAL_MS = 20000

function formatAlertTime(value) {
  const date = new Date(value)
  const elapsed = Date.now() - date.getTime()
  if (!Number.isFinite(elapsed) || elapsed < 60000) return 'Now'
  if (elapsed < 3600000) return `${Math.floor(elapsed / 60000)}m ago`
  if (elapsed < 86400000) return `${Math.floor(elapsed / 3600000)}h ago`
  return new Intl.DateTimeFormat('en-PH', { month: 'short', day: 'numeric', year: date.getFullYear() === new Date().getFullYear() ? undefined : 'numeric' }).format(date)
}

function createOrderNotifications(records) {
  return records.map((record) => {
    return {
      id: String(record.id),
      readAt: record.read_at,
      status: record.type === 'order_cancelled' ? 'cancelled' : 'updated',
      title: record.title,
      message: record.body,
      orderNumber: record.entity_id ? `Order #${record.entity_id}` : 'Order update',
      createdAt: record.created_at,
      href: record.entity_id ? `/buyer/delivery-progress?track=${encodeURIComponent(record.entity_id)}` : '/buyer/delivery-progress',
    }
  })
}

export function BuyerHeader({ active = 'home', cartCount }) {
  const { profile, signOut } = useAuth()
  const buyerName = profile?.full_name || 'Buyer'
  const displayedCartCount = cartCount ?? buyerCartQuantity(readBuyerCart())
  const [unreadCount, setUnreadCount] = useState(0)
  const [notifications, setNotifications] = useState([])
  const [notificationsLoading, setNotificationsLoading] = useState(true)
  const [notificationsError, setNotificationsError] = useState(false)
  const [readNotificationIds, setReadNotificationIds] = useState(readBuyerNotificationIds)
  const notificationMenuRef = useRef(null)
  const notificationUnreadCount = notifications.filter((notification) => !isBuyerNotificationRead(notification, readNotificationIds)).length
  const aboutActive = active === 'about'
  const homeActive = active === 'home'

  useEffect(() => {
    let cancelled = false

    async function fetchUnreadCount() {
      try {
        const count = await loadBuyerUnreadCount()
        if (!cancelled) setUnreadCount(count)
      } catch {
        // Badge just won't refresh this cycle; not worth surfacing an error for.
      }
    }

    fetchUnreadCount()
    const interval = window.setInterval(fetchUnreadCount, UNREAD_POLL_INTERVAL_MS)
    return () => {
      cancelled = true
      window.clearInterval(interval)
    }
  }, [])

  useEffect(() => {
    let cancelled = false

    async function fetchNotifications() {
      try {
        const result = await loadBuyerNotifications()
        if (!cancelled) {
          setNotifications(createOrderNotifications(result.notifications || []))
          setNotificationsError(false)
        }
      } catch {
        if (!cancelled) setNotificationsError(true)
      } finally {
        if (!cancelled) setNotificationsLoading(false)
      }
    }

    fetchNotifications()
    const interval = window.setInterval(fetchNotifications, UNREAD_POLL_INTERVAL_MS)
    return () => {
      cancelled = true
      window.clearInterval(interval)
    }
  }, [])

  useEffect(() => {
    function closeNotificationMenu(event) {
      if (notificationMenuRef.current && !notificationMenuRef.current.contains(event.target)) {
        notificationMenuRef.current.removeAttribute('open')
      }
    }
    function closeOnEscape(event) {
      if (event.key === 'Escape') notificationMenuRef.current?.removeAttribute('open')
    }
    document.addEventListener('pointerdown', closeNotificationMenu)
    document.addEventListener('keydown', closeOnEscape)
    return () => {
      document.removeEventListener('pointerdown', closeNotificationMenu)
      document.removeEventListener('keydown', closeOnEscape)
    }
  }, [])

  useEffect(() => {
    const syncReadIds = () => setReadNotificationIds(readBuyerNotificationIds())
    window.addEventListener(BUYER_NOTIFICATION_READ_EVENT, syncReadIds)
    window.addEventListener('storage', syncReadIds)
    return () => {
      window.removeEventListener(BUYER_NOTIFICATION_READ_EVENT, syncReadIds)
      window.removeEventListener('storage', syncReadIds)
    }
  }, [])

  function saveReadNotifications(ids) {
    setReadNotificationIds(saveBuyerNotificationIds(ids))
  }

  function markNotificationRead(id) {
    const currentIds = readBuyerNotificationIds()
    if (currentIds.includes(id)) return
    saveReadNotifications([...currentIds, id])
  }

  function markAllNotificationsRead() {
    saveReadNotifications([...readBuyerNotificationIds(), ...notifications.map((notification) => notification.id)])
  }

  async function handleSignOut() {
    await signOut()
    window.location.replace('/login')
  }

  return (
    <header className="buyer-site-header">
      <div className="buyer-header-main">
        <a className="buyer-brand" href="/buyer" aria-label="JToledo Trading home">
          <img src={jtoledoLogo} alt="JToledo Trading" />
        </a>

        <nav className="buyer-main-nav" aria-label="Buyer navigation">
          <a className={aboutActive ? 'is-active' : ''} href="/buyer/about" aria-current={aboutActive ? 'page' : undefined}>About Us</a>
          <a className={homeActive ? 'is-active' : ''} href="/buyer" aria-current={homeActive ? 'page' : undefined}>Home</a>
          <a className={active === 'orders' ? 'is-active' : ''} href="/buyer/order" aria-current={active === 'orders' ? 'page' : undefined}>Order</a>
        </nav>

        <div className="buyer-header-tools">
          <div className="buyer-header-alerts" aria-label="Messages and notifications">
            <a
              className={`buyer-icon-link${active === 'messages' ? ' is-active' : ''}`}
              href="/buyer/messages"
              aria-label={unreadCount > 0 ? `Messages (${unreadCount} unread)` : 'Messages'}
              aria-current={active === 'messages' ? 'page' : undefined}
            >
              <MessageCircle aria-hidden="true" />
              {unreadCount > 0 && (
                <span className="buyer-status-dot">{unreadCount > 99 ? '99+' : unreadCount}</span>
              )}
            </a>
            <details className={`buyer-notification-menu${active === 'notifications' ? ' is-active' : ''}`} ref={notificationMenuRef}>
              <summary className="buyer-icon-link" aria-label={notificationUnreadCount ? `Notifications (${notificationUnreadCount} unread)` : 'Notifications'}>
                <Bell aria-hidden="true" />
                {notificationUnreadCount > 0 && <span className="buyer-status-dot">{notificationUnreadCount > 99 ? '99+' : notificationUnreadCount}</span>}
              </summary>
              <section className="buyer-notification-dropdown" aria-label="Recent notifications">
                <header><div><h2>Notifications</h2><p>Recent order updates</p></div>{notificationUnreadCount > 0 && <button type="button" onClick={markAllNotificationsRead}>Mark all as read</button>}</header>
                <div className="buyer-notification-list">
                  {notificationsLoading && <p className="buyer-notification-state">Loading notifications…</p>}
                  {!notificationsLoading && notificationsError && <p className="buyer-notification-state is-error">Notifications could not be refreshed.</p>}
                  {!notificationsLoading && !notificationsError && notifications.length === 0 && <p className="buyer-notification-state">You have no order updates yet.</p>}
                  {!notificationsLoading && notifications.slice(0, 4).map((notification) => (
                    <a className={`buyer-notification-item${isBuyerNotificationRead(notification, readNotificationIds) ? '' : ' is-unread'}`} href={notification.href} onClick={() => markNotificationRead(notification.id)} key={notification.id}>
                      <span className={`buyer-notification-icon is-${notification.status}`}>
                        {notification.status === 'delivered' ? <CheckCircle2 aria-hidden="true" /> : notification.status === 'out_for_delivery' ? <Truck aria-hidden="true" /> : notification.status === 'pending' ? <Clock3 aria-hidden="true" /> : <PackageCheck aria-hidden="true" />}
                      </span>
                      <span className="buyer-notification-copy"><strong>{notification.title}</strong><small>{notification.orderNumber}</small><p>{notification.message}</p><time dateTime={notification.createdAt}>{formatAlertTime(notification.createdAt)}</time></span>
                      {!isBuyerNotificationRead(notification, readNotificationIds) && <i aria-label="Unread" />}
                    </a>
                  ))}
                </div>
                <footer><a href="/buyer/notifications">View all notifications <span aria-hidden="true">→</span></a></footer>
              </section>
            </details>
          </div>

          <div className="buyer-header-account">
            <a className={`buyer-cart-link ${active === 'cart' ? 'is-active' : ''}`} href="/buyer/cart" aria-label="Shopping cart" aria-current={active === 'cart' ? 'page' : undefined}>
              <ShoppingCart aria-hidden="true" />
              {displayedCartCount > 0 && <span className="buyer-cart-count">{displayedCartCount > 99 ? '99+' : displayedCartCount}</span>}
            </a>
            <details className={`buyer-profile-menu${active === 'profile' ? ' is-active' : ''}`}>
              <summary>
                <span className="buyer-avatar"><UserRound aria-hidden="true" /></span>
                <span className="buyer-profile-name">{buyerName}</span>
                <ChevronDown className="buyer-profile-chevron" aria-hidden="true" />
              </summary>
              <div className="buyer-profile-dropdown">
                <a href="/buyer/delivery-progress">My Orders</a>
                <a href="/buyer/profile" aria-current={active === 'profile' ? 'page' : undefined}>My Profile</a>
                <button className="buyer-signout-button" type="button" onClick={handleSignOut}><LogOut aria-hidden="true" />Sign Out</button>
              </div>
            </details>
          </div>
        </div>
      </div>

      <details className="buyer-mobile-menu">
        <summary aria-label="Open navigation"><Menu aria-hidden="true" /></summary>
        <nav aria-label="Mobile buyer navigation">
          <a className={aboutActive ? 'is-active' : ''} href="/buyer/about" aria-current={aboutActive ? 'page' : undefined}>About Us</a>
          <a className={homeActive ? 'is-active' : ''} href="/buyer" aria-current={homeActive ? 'page' : undefined}>Home</a>
          <a className={active === 'orders' ? 'is-active' : ''} href="/buyer/order" aria-current={active === 'orders' ? 'page' : undefined}>Order</a>
          <a className={active === 'cart' ? 'is-active' : ''} href="/buyer/cart" aria-current={active === 'cart' ? 'page' : undefined}>Shopping Cart</a>
          <a className={active === 'messages' ? 'is-active' : ''} href="/buyer/messages" aria-current={active === 'messages' ? 'page' : undefined}>Messages</a>
          <a className={active === 'notifications' ? 'is-active' : ''} href="/buyer/notifications" aria-current={active === 'notifications' ? 'page' : undefined}>Notifications{notificationUnreadCount > 0 ? ` (${notificationUnreadCount})` : ''}</a>
          <a href="/buyer/delivery-progress">My Orders</a>
          <a className={active === 'profile' ? 'is-active' : ''} href="/buyer/profile" aria-current={active === 'profile' ? 'page' : undefined}>My Profile</a>
          <button className="buyer-signout-button" type="button" onClick={handleSignOut}><LogOut aria-hidden="true" />Sign Out</button>
        </nav>
      </details>
    </header>
  )
}

const buyerJourneySteps = [
  { id: 'order', label: 'Order', href: '/buyer/order' },
  { id: 'cart', label: 'Shopping Cart', href: '/buyer/cart' },
  { id: 'checkout', label: 'Checkout', href: '/buyer/checkout' },
  { id: 'delivery', label: 'Delivery', href: '/buyer/delivery-progress' },
]

export function BuyerJourneyNav({ current }) {
  return (
    <nav className="buyer-journey-nav" aria-label="Order process">
      <ol>
        {buyerJourneySteps.map((step, index) => (
          <li key={step.id}>
            {index > 0 && <span className="buyer-journey-separator" aria-hidden="true">&gt;</span>}
            <a className={current === step.id ? 'is-current' : ''} href={step.href} aria-current={current === step.id ? 'step' : undefined}>
              {step.label}
            </a>
          </li>
        ))}
      </ol>
    </nav>
  )
}

export function BuyerFooter() {
  return (
    <footer className="buyer-site-footer">
      <div className="buyer-footer-grid">
        <section>
          <h2>About Jtoledo Trading</h2>
          <p>JToledo Trading is a privately owned agricultural enterprise in Tagaytay specializing in pineapple farming and distribution, with over 25 years of farming operations managed by Joseph Toledo.</p>
        </section>
        <section>
          <h2>Navigation</h2>
          <nav className="buyer-footer-links" aria-label="Footer navigation">
            <a href="/buyer/about">About Us</a>
            <a href="#contact">Contact Us</a>
          </nav>
        </section>
        <section id="contact">
          <h2>Contact</h2>
          <ul className="buyer-contact-list">
            <li><strong>Mobile Number:</strong> 09989947159</li>
            <li><strong>Email:</strong> jperetoledo7@gmail.com</li>
            <li><strong>Address:</strong> 107 Daang Malabag, Brgy. Malabag, Silang, Cavite 4118, Philippines</li>
          </ul>
        </section>
        <section>
          <h2>Stay Connected</h2>
          <p>Stay connected with our latest news and price alerts to never miss a great deal.</p>
          <form className="buyer-newsletter" onSubmit={(event) => event.preventDefault()}>
            <label className="sr-only" htmlFor="buyer-email">Email Address</label>
            <Mail aria-hidden="true" />
            <input id="buyer-email" type="email" placeholder="Email Address" />
            <button type="submit" aria-label="Subscribe"><Send aria-hidden="true" /></button>
          </form>
        </section>
      </div>
      <div className="buyer-footer-bottom">
        <span>© 2026 All rights reserved.</span>
        <div><a href="#terms">Terms &amp; Conditions</a><a href="#privacy">Privacy Policy</a></div>
      </div>
    </footer>
  )
}
