import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { ArrowLeft, CheckCheck, ChevronDown, Clock, MessageSquare, Search, Send } from 'lucide-react'
import { AdminSidebar, AdminTopbar } from '../../components/AdminNavigation.jsx'
import { loadAdminConversation, loadAdminConversations, sendAdminMessage, setAdminTyping } from '../../services/adminMessages.js'
import '../../styles/admin-dashboard.css'
import '../../styles/admin-messages.css'

// Formats the time shown beside a message.
function formatTime(value) {
  if (!value) return ''
  return new Intl.DateTimeFormat('en-US', { hour: 'numeric', minute: '2-digit' }).format(new Date(value))
}

// Formats the latest message time in the conversation list.
function formatListTime(value) {
  if (!value) return ''
  const date = new Date(value)
  const today = new Date()
  if (date.toDateString() === today.toDateString()) {
    return formatTime(value)
  }
  return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric' }).format(date)
}

// Displays buyer conversations for the admin.
export default function AdminMessages() {
  const [conversations, setConversations] = useState([])
  const [conversationsLoading, setConversationsLoading] = useState(true)
  const [selectedId, setSelectedId] = useState(null)
  const [mobileThreadOpen, setMobileThreadOpen] = useState(false)
  const [messages, setMessages] = useState([])
  const [threadLoading, setThreadLoading] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [draft, setDraft] = useState('')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState('')
  const [selectedPresence, setSelectedPresence] = useState(null)
  const [buyerTyping, setBuyerTyping] = useState(false)
  const [showJumpToLatest, setShowJumpToLatest] = useState(false)
  const historyRef = useRef(null)
  const shouldScrollToLatestRef = useRef(true)

  // Shows the jump button when the message view is scrolled up.
  function updateJumpToLatest() {
    const history = historyRef.current
    if (!history) return
    setShowJumpToLatest(history.scrollHeight - history.scrollTop - history.clientHeight > 48)
  }

  // Scrolls the open conversation to its newest message.
  function scrollToLatest(behavior = 'smooth') {
    const history = historyRef.current
    if (!history) return
    history.scrollTo({ top: history.scrollHeight, behavior })
    setShowJumpToLatest(false)
  }

  // Loads the buyer conversation list.
  const fetchConversations = useCallback(async (isBackground = false) => {
    try {
      const data = await loadAdminConversations()
      setConversations(data)
      return data
    } catch (err) {
      if (!isBackground) setError(err.message)
      return []
    } finally {
      if (!isBackground) setConversationsLoading(false)
    }
  }, [])

  // Loads messages and presence for the selected conversation.
  const fetchCurrentThread = useCallback(async (id, isBackground = false) => {
    if (!id) return
    if (!isBackground) setThreadLoading(true)
    try {
      const { conversation, messages: loaded } = await loadAdminConversation(id)
      setMessages(loaded)
      setSelectedPresence(conversation?.is_online ?? null)
      setBuyerTyping(Boolean(conversation?.is_typing))
    } catch (err) {
      if (!isBackground) setError(err.message)
    } finally {
      if (!isBackground) setThreadLoading(false)
    }
  }, [])

  // Selects a conversation after the list loads.
  useEffect(() => {
    fetchConversations().then((data) => {
      if (data.length > 0) setSelectedId((curr) => curr || data[0].id)
    })
  }, [fetchConversations])

  // Poll frequently enough for typing indicators while also receiving new messages.
  useEffect(() => {
    const interval = setInterval(() => {
      fetchConversations(true)
      if (selectedId) {
        fetchCurrentThread(selectedId, true)
      }
    }, 3000)

    return () => clearInterval(interval)
  }, [fetchConversations, fetchCurrentThread, selectedId])

  // Loads the newly selected conversation.
  useEffect(() => {
    if (selectedId) {
      shouldScrollToLatestRef.current = true
      setSelectedPresence(null)
      fetchCurrentThread(selectedId, false)
    }
  }, [selectedId, fetchCurrentThread])

  // Keeps the latest message in view when messages change.
  useEffect(() => {
    if (shouldScrollToLatestRef.current) {
      scrollToLatest('auto')
      shouldScrollToLatestRef.current = false
    } else {
      updateJumpToLatest()
    }
  }, [messages, mobileThreadOpen])

  // Sends the drafted message to the selected buyer.
  async function handleSend() {
    const body = draft.trim()
    if (!body || sending || !selectedId) return
    setSending(true)
    setError('')
    try {
      const message = await sendAdminMessage(selectedId, body)
      shouldScrollToLatestRef.current = true
      setMessages((current) => [...current, message])
      setDraft('')
      fetchConversations(true)
    } catch (err) {
      setError(err.message)
    } finally {
      setSending(false)
    }
  }

  // Sends the message when the form is submitted.
  function onSubmit(event) {
    event.preventDefault()
    handleSend()
  }

  // Sends on Enter while allowing Shift+Enter for a new line.
  function handleKeyDown(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault()
      handleSend()
    }
  }

  const adminIsTyping = Boolean(draft.trim()) && !sending && Boolean(selectedId)

  // Updates the buyer while the admin is typing.
  useEffect(() => {
    if (!adminIsTyping || !selectedId) return undefined

    setAdminTyping(selectedId, true).catch(() => {})
    const interval = window.setInterval(() => {
      setAdminTyping(selectedId, true).catch(() => {})
    }, 2500)

    return () => {
      window.clearInterval(interval)
      setAdminTyping(selectedId, false).catch(() => {})
    }
  }, [adminIsTyping, selectedId])

  // Filters conversations by buyer name or message text.
  const filteredConversations = useMemo(() => {
    if (!searchQuery.trim()) return conversations
    const q = searchQuery.toLowerCase()
    return conversations.filter(
      (c) =>
        c.buyer?.full_name?.toLowerCase().includes(q) ||
        c.last_message?.body?.toLowerCase().includes(q)
    )
  }, [conversations, searchQuery])

  const selectedConversation = conversations.find((c) => c.id === selectedId)
  const buyerOnline = selectedPresence ?? Boolean(selectedConversation?.is_online)
  const lastAdminMessageId = [...messages]
    .reverse()
    .find((message) => message.sender_role === 'admin')?.id

  return (
    <main className={`admin-dashboard admin-messages-page${mobileThreadOpen && selectedConversation ? ' is-mobile-thread-open' : ''}`}>
      {/* Admin navigation and page header. */}
      <AdminSidebar active="messages" />
      <section className="admin-workspace">
        <AdminTopbar />

        <div className="admin-messages-content">
          {error && <div className="admin-messages-error">{error}</div>}

          {/* Conversation list and active message thread. */}
          <div className="admin-messages-shell">
            {/* Sidebar list */}
            <aside className="admin-messages-list" aria-label="Buyer Conversations">
              <header className="admin-mobile-inbox-heading">
                <h1>Messages</h1>
                <p>Conversations with your buyers</p>
              </header>
              <div className="admin-messages-search-bar">
                <div className="admin-search-input-wrapper">
                  <Search size={16} className="search-icon" aria-hidden="true" />
                  <input
                    type="text"
                    placeholder="Search buyers or messages..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>

              <div className="admin-messages-scroll-list">
                {conversationsLoading && (
                  <p className="admin-messages-empty">Loading conversations…</p>
                )}

                {!conversationsLoading && filteredConversations.length === 0 && (
                  <div className="admin-messages-empty-list">
                    <MessageSquare size={28} />
                    <p>{searchQuery ? 'No matching buyers found' : 'No buyer messages yet.'}</p>
                  </div>
                )}

                {filteredConversations.map((conversation) => {
                  const isActive = conversation.id === selectedId
                  const initial = (conversation.buyer?.full_name || 'B').charAt(0).toUpperCase()

                  return (
                    <button
                      key={conversation.id}
                      type="button"
                      className={`admin-messages-list-item${isActive ? ' is-active' : ''}`}
                      onClick={() => {
                        if (conversation.id !== selectedId) setDraft('')
                        shouldScrollToLatestRef.current = true
                        setSelectedId(conversation.id)
                        setMobileThreadOpen(true)
                      }}
                    >
                      <div className="admin-messages-list-avatar" aria-hidden="true">
                        {initial}
                        <span className={`admin-list-presence${conversation.is_online ? ' is-online' : ' is-offline'}`} />
                      </div>

                      <div className="admin-messages-list-info">
                        <div className="admin-item-top">
                          <strong className="admin-item-name">
                            {conversation.buyer?.full_name || 'Buyer'}
                          </strong>
                          <time className="admin-item-time">
                            {formatListTime(conversation.last_message_at)}
                          </time>
                        </div>

                        <div className="admin-item-bottom">
                          <span className="admin-messages-list-preview">
                            {conversation.is_typing ? 'Typing…' : conversation.last_message?.body || 'No messages yet'}
                          </span>
                          {conversation.unread_count > 0 && (
                            <span className="admin-messages-unread">
                              {conversation.unread_count}
                            </span>
                          )}
                        </div>
                      </div>
                    </button>
                  )
                })}
              </div>
            </aside>

            {/* Active Thread */}
            <div className="admin-messages-thread">
              {!selectedConversation && !conversationsLoading && (
                <div className="admin-messages-thread-placeholder">
                  <div className="placeholder-icon">
                    <MessageSquare size={36} />
                  </div>
                  <h3>Customer Messages</h3>
                  <p>Select a buyer from the list on the left to review or reply to messages.</p>
                </div>
              )}

              {selectedConversation && (
                <>
                  <header className="admin-messages-thread-header">
                    <button className="admin-chat-back" type="button" aria-label="Back to conversations"
                      onClick={() => setMobileThreadOpen(false)}>
                      <ArrowLeft size={22} aria-hidden="true" />
                    </button>
                    <div className="admin-thread-user-info">
                      <div className="admin-thread-avatar">
                        {(selectedConversation.buyer?.full_name || 'B').charAt(0).toUpperCase()}
                        <span className={`admin-avatar-presence${buyerOnline ? ' is-online' : ' is-offline'}`} />
                      </div>
                      <div className="admin-thread-details">
                        <h2>{selectedConversation.buyer?.full_name || 'Buyer'}</h2>
                        <p className={`admin-thread-status${buyerOnline ? ' is-online' : ' is-offline'}`}>
                          <span className="presence-dot" aria-hidden="true" />
                          {buyerOnline ? 'Online' : 'Offline'}
                        </p>
                      </div>
                    </div>
                  </header>

                  <div
                    className="admin-messages-history"
                    ref={historyRef}
                    onScroll={updateJumpToLatest}
                    aria-live="polite"
                  >
                    {threadLoading && (
                      <p className="admin-messages-empty">Loading messages…</p>
                    )}

                    {!threadLoading &&
                      messages.map((message) => {
                        const isAdmin = message.sender_role === 'admin'

                        return (
                          <article
                            className={`admin-messages-bubble admin-messages-bubble--${
                              isAdmin ? 'admin' : 'buyer'
                            }`}
                            key={message.id}
                          >
                            <div className="admin-bubble-body">
                              <p>{message.body}</p>
                            </div>
                            <div className="admin-bubble-meta">
                              <time dateTime={message.created_at}>
                                <Clock size={10} aria-hidden="true" />
                                {formatTime(message.created_at)}
                              </time>
                              {isAdmin && message.id === lastAdminMessageId && (
                                <span
                                  className={`admin-read-receipt${message.read_at ? ' is-seen' : ''}`}
                                  title={message.read_at ? 'Seen' : 'Delivered'}
                                  aria-label={message.read_at ? 'Seen' : 'Delivered'}
                                >
                                  <CheckCheck size={13} aria-hidden="true" />
                                  <span>{message.read_at ? 'Seen' : 'Delivered'}</span>
                                </span>
                              )}
                            </div>
                          </article>
                        )
                    })}
                    {!threadLoading && buyerTyping && (
                      <div className="admin-typing-row" role="status" aria-label={`${selectedConversation.buyer?.full_name || 'Buyer'} is typing`}>
                        <div className="chat-typing-indicator">
                          <span /><span /><span />
                        </div>
                        <small>{selectedConversation.buyer?.full_name || 'Buyer'} is typing</small>
                      </div>
                    )}
                  </div>

                  {showJumpToLatest && (
                    <button
                      type="button"
                      className="chat-jump-to-latest admin-chat-jump-to-latest"
                      onClick={() => scrollToLatest()}
                      aria-label="Scroll to latest message"
                    >
                      <ChevronDown size={18} aria-hidden="true" />
                      <span>Latest</span>
                    </button>
                  )}

                  <form className="admin-messages-composer" onSubmit={onSubmit}>
                    <label className="sr-only" htmlFor="admin-message-input">
                      Write a reply to {selectedConversation.buyer?.full_name || 'Buyer'}
                    </label>
                    <div className="admin-composer-input-wrapper">
                      <input
                        id="admin-message-input"
                        type="text"
                        value={draft}
                        onChange={(event) => setDraft(event.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder={`Reply to ${selectedConversation.buyer?.full_name || 'Buyer'}...`}
                        disabled={sending}
                        autoComplete="off"
                      />
                    </div>
                    <button
                      type="submit"
                      className="admin-send-btn"
                      aria-label="Send reply"
                      disabled={sending || !draft.trim()}
                    >
                      <Send size={18} aria-hidden="true" />
                    </button>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}

