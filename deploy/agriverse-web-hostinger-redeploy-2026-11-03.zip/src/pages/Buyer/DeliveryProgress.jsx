import { useCallback, useEffect, useMemo, useState } from 'react'
import {
  CalendarDays,
  Camera,
  Check,
  ChevronLeft,
  ChevronRight,
  MapPin,
  Maximize2,
  PackageCheck,
  PackageOpen,
  ReceiptText,
  Search,
  Star,
  Store,
  Truck,
  X,
  XCircle,
} from 'lucide-react'
import { BuyerFooter, BuyerHeader } from '../../components/BuyerChrome.jsx'
import ProgressStepper from '../../components/ProgressStepper.jsx'
import { buildReturnSteps } from '../../components/returnSteps.js'
import ReturnDecision from '../../components/ReturnDecision.jsx'
import { qrphRefundLink } from '../../utils/paymongoRefund.js'
import pineappleImage from '../../assets/buyer/pineapple-product-clean.png'
import {
  buyerCartQuantity,
  cancelBuyerOrder,
  confirmBuyerOrderReceipt,
  loadBuyerOrder,
  loadBuyerOrders,
  readBuyerCart,
  rateBuyerOrder,
  writeBuyerCart,
} from '../../services/buyerMarketplace.js'
import '../../styles/Buyer/buyerLanding.css'
import '../../styles/Buyer/deliveryProgress.css'

const statusRank = {
  pending: 0,
  confirmed: 1,
  preparing: 1,
  ready_for_delivery: 1,
  out_for_delivery: 2,
  ready_for_pickup: 2,
  delivered: 3,
  completed: 4,
}

const statusLabels = {
  pending: 'Pending',
  confirmed: 'Confirmed',
  preparing: 'Preparing',
  ready_for_delivery: 'Ready for Delivery',
  out_for_delivery: 'Out for Delivery',
  ready_for_pickup: 'Ready for Pickup',
  delivered: 'Delivered',
  completed: 'Completed',
  cancelled: 'Cancelled',
}

const DISPUTE_CATEGORY_OPTIONS = [
  { value: 'damaged', label: 'Damaged', description: 'Crushed, bruised, or otherwise damaged' },
  { value: 'spoiled_rotten', label: 'Spoiled / Rotten', description: 'Not fresh or no longer safe to use' },
  { value: 'wrong_item', label: 'Wrong item', description: 'Different product or size than ordered' },
  { value: 'missing_item', label: 'Missing item', description: 'An item from the order was not included' },
  { value: 'wrong_quantity', label: 'Wrong quantity', description: 'You received fewer items than ordered' },
]

const disputeCategoryLabels = Object.fromEntries(DISPUTE_CATEGORY_OPTIONS.map((option) => [option.value, option.label]))

const CANCEL_REASONS = [
  { value: 'changed_mind', label: 'I changed my mind' },
  { value: 'mistake', label: 'I ordered by mistake' },
  { value: 'price', label: 'Found a better price elsewhere' },
  { value: 'slow', label: 'Delivery is taking too long' },
  { value: 'other', label: 'Other' },
]

const PAYMENT_METHOD_LABELS = {
  cash: 'Cash on Delivery',
  bank: 'Bank Transfer',
  gcash: 'GCash',
  qrph: 'QR Ph',
}

// Checks whether an order can still be cancelled.
function canCancelOrder(order) {
  return ['pending', 'confirmed'].includes(order.order_status)
}

const RATING_LABELS = { 1: 'Poor', 2: 'Fair', 3: 'Good', 4: 'Great', 5: 'Excellent' }

// Displays a read-only or selectable star rating.
function StarRating({ value, size = 16, interactive = false, onHover, onSelect }) {
  return (
    <div className="star-rating" onMouseLeave={interactive ? () => onHover(0) : undefined}>
      {[1, 2, 3, 4, 5].map((n) => {
        const filled = n <= value
        const star = <Star size={size} fill={filled ? '#e9a528' : 'none'} stroke={filled ? '#e9a528' : '#c7cdc6'} strokeWidth={1.5} aria-hidden="true" />
        return interactive ? (
          <button
            key={n}
            type="button"
            className="star-rating-btn"
            aria-label={`${n} star${n === 1 ? '' : 's'} — ${RATING_LABELS[n]}`}
            onMouseEnter={() => onHover(n)}
            onClick={() => onSelect(n)}
          >
            {star}
          </button>
        ) : <span key={n}>{star}</span>
      })}
    </div>
  )
}

const ORDER_FILTERS = [
  { id: 'all', label: 'All' },
  { id: 'to_pay', label: 'To Pay' },
  { id: 'preparing', label: 'To Ship' },
  { id: 'to_receive', label: 'To Receive' },
  { id: 'completed', label: 'Completed' },
  { id: 'cancelled', label: 'Cancelled' },
  { id: 'returns', label: 'Returns & Refunds' },
]

// Checks whether an order has a return or refund case.
function isReturnOrRefund(order) {
  // A cancelled order stays under Cancelled, including while its refund is pending.
  if (order.order_status === 'cancelled') return false
  return order.payment_status === 'refunded' || Boolean(order.delivery_dispute_status)
}

// Checks whether an online order still needs payment.
function needsPayment(order) {
  return ['gcash', 'qrph'].includes(order.payment_method) && order.order_status !== 'cancelled' && ['unpaid', 'pending', 'failed'].includes(order.payment_status)
}

// Checks whether an order belongs in the selected status tab.
function matchesOrderFilter(order, filter) {
  if (filter === 'all') return true
  if (filter === 'returns') return isReturnOrRefund(order)
  // A disputed/refunded order belongs only in Returns & Refunds, regardless of its underlying order_status.
  if (isReturnOrRefund(order)) return false
  if (filter === 'to_pay') return needsPayment(order)
  // An order still awaiting payment belongs only in To Pay until it's settled, regardless of fulfillment progress.
  if (needsPayment(order)) return false
  if (filter === 'preparing') {
    return ['pending', 'confirmed', 'preparing', 'ready_for_delivery'].includes(order.order_status)
  }
  if (filter === 'to_receive') {
    return ['out_for_delivery', 'ready_for_pickup', 'delivered'].includes(order.order_status)
  }
  if (filter === 'completed') return order.order_status === 'completed'
  if (filter === 'cancelled') return order.order_status === 'cancelled'
  return true
}

// Formats an order date for display.
function formatDate(value, includeTime = false) {
  if (!value) return 'Pending'
  return new Intl.DateTimeFormat('en-PH', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
    ...(includeTime ? { hour: 'numeric', minute: '2-digit' } : {}),
  }).format(new Date(value))
}

// Formats a shorter date label.
function formatShortDate(value) {
  if (!value) return ''
  return new Intl.DateTimeFormat('en-PH', { month: 'short', day: 'numeric' }).format(new Date(value))
}

// Displays an icon beside an order detail.
function IconBadge({ icon: Icon }) {
  return <span className="delivery-icon-badge"><Icon aria-hidden="true" /></span>
}

// A delivered/completed order that has a return: the fulfilment steps are all done, so the
// route card shrinks to one line and the return card leads the page.
// Checks whether completed progress steps can be collapsed.
function canCollapseProgress(order) {
  return isReturnOrRefund(order) && ['delivered', 'completed'].includes(order.order_status)
}

// Summarizes the current delivery progress.
function progressSummary(order) {
  const isPickup = order.delivery_method === 'pickup'
  const when = isPickup ? (order.picked_up_at || order.completed_at) : (order.delivered_at || order.completed_at)
  const detail = [
    ['Placed', order.created_at],
    ['Packed', order.preparing_at || order.confirmed_at],
    [isPickup ? 'Ready' : 'Shipped', isPickup ? order.ready_for_pickup_at : order.out_for_delivery_at],
  ].filter(([, date]) => date).map(([label, date]) => `${label} ${formatShortDate(date)}`).join(' · ')
  return {
    headline: `${isPickup ? 'Picked up at the farm' : 'Delivered'}${when ? ` on ${formatDate(when)}` : ''}`,
    detail,
  }
}

// Builds the order's delivery progress steps.
function createMilestones(order) {
  const rank = statusRank[order.order_status] ?? 0
  const isPickup = order.delivery_method === 'pickup'
  return [
    { label: 'Order Placed', date: order.created_at, icon: ReceiptText },
    {
      label: 'Confirmed & Packing',
      date: order.preparing_at || order.confirmed_at,
      icon: PackageOpen,
    },
    isPickup
      ? { label: 'Ready for Pickup', date: order.ready_for_pickup_at, icon: Store, estimated: !order.ready_for_pickup_at }
      : { label: 'In Transit', date: order.out_for_delivery_at, icon: Truck },
    isPickup
      ? { label: 'Picked Up', date: order.picked_up_at || order.completed_at, icon: Check, estimated: !order.picked_up_at }
      : { label: 'Delivered', date: order.delivered_at || order.estimated_delivery_at, icon: Check, estimated: !order.delivered_at },
  ].map((milestone, index) => (order.order_status === 'cancelled'
    ? { ...milestone, complete: Boolean(milestone.date) && !milestone.estimated, current: false }
    : { ...milestone, complete: index < rank, current: index === rank }))
}

// Summarizes an order's products for search.
function orderItemsText(order) {
  return order.items.map((item) => `${item.quantity} ${item.product_name}`).join(', ')
}

// Split the address so the place a buyer recognises leads and the rest sits underneath.
// Country is dropped, since every order is delivered in the same one.
// Builds the delivery address shown for an order.
function getDeliveryAddress(order) {
  const primary = [order.delivery_barangay, order.delivery_city_municipality].filter(Boolean).join(', ')
  const secondary = [order.delivery_province, order.delivery_region].filter(Boolean).join(', ')
  return primary
    ? { primary, secondary }
    : { primary: secondary, secondary: '' }
}

// Displays buyer order history and delivery tracking.
export default function DeliveryProgress() {
  // Reads an order to track directly from the page URL.
  const trackedOrderId = useMemo(() => {
    const value = Number(new URLSearchParams(window.location.search).get('track'))
    return Number.isSafeInteger(value) && value > 0 ? value : null
  }, [])
  const [orders, setOrders] = useState([])
  const [selectedOrderId, setSelectedOrderId] = useState(null)
  const [activeFilter, setActiveFilter] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [confirming, setConfirming] = useState(false)
  const [confirmingOrderId, setConfirmingOrderId] = useState(null)
  const [receiptError, setReceiptError] = useState('')
  const [viewingDeliveryProof, setViewingDeliveryProof] = useState(false)
  const [showFullProgress, setShowFullProgress] = useState(false)
  const [showPreCancelDetails, setShowPreCancelDetails] = useState(false)
  const [cancelTarget, setCancelTarget] = useState(null)
  const [cancelReason, setCancelReason] = useState('')
  const [cancelNote, setCancelNote] = useState('')
  const [cancelling, setCancelling] = useState(false)
  const [cancelError, setCancelError] = useState('')
  const [rateTarget, setRateTarget] = useState(null)
  const [rateValue, setRateValue] = useState(0)
  const [rateCardHover, setRateCardHover] = useState(0)
  const [rateHoverValue, setRateHoverValue] = useState(0)
  const [rateComment, setRateComment] = useState('')
  const [rateSubmitting, setRateSubmitting] = useState(false)
  const [rateError, setRateError] = useState('')
  const [rateSubmitted, setRateSubmitted] = useState(false)

  // Loads the buyer's orders or the directly tracked order.
  const fetchOrders = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const loadedOrders = trackedOrderId
        ? [await loadBuyerOrder(trackedOrderId)]
        : await loadBuyerOrders()
      setOrders(loadedOrders)
      setSelectedOrderId((current) => {
        if (trackedOrderId) return trackedOrderId
        if (loadedOrders.some((order) => order.id === current)) return current
        return null
      })
    } catch (requestError) {
      setOrders([])
      setError(requestError.message)
    } finally {
      setLoading(false)
    }
  }, [trackedOrderId])

  // Loads orders when the page opens.
  useEffect(() => { fetchOrders() }, [fetchOrders])

  // Fetching the single order (rather than reusing the list) is what lets the backend
  // reconcile GCash payment status and the buyer-confirmation auto-complete timeout.
  useEffect(() => {
    if (!selectedOrderId || trackedOrderId) return undefined
    let cancelled = false
    loadBuyerOrder(selectedOrderId)
      .then((freshOrder) => {
        if (cancelled) return
        setOrders((current) => current.map((order) => (order.id === freshOrder.id ? freshOrder : order)))
      })
      .catch(() => {})
    return () => { cancelled = true }
  }, [selectedOrderId, trackedOrderId])

  // Finds the order open in the detail view.
  const selectedOrder = useMemo(
    () => orders.find((order) => order.id === selectedOrderId) || null,
    [orders, selectedOrderId],
  )

  // Filters orders by the selected status.
  const filteredOrders = useMemo(
    () => orders.filter((order) => matchesOrderFilter(order, activeFilter)),
    [activeFilter, orders],
  )

  // Searches within the filtered order list.
  const visibleOrders = useMemo(() => {
    const query = searchQuery.trim().toLowerCase()
    if (!query) return filteredOrders
    return filteredOrders.filter((order) => [
      order.order_number,
      orderItemsText(order),
      statusLabels[order.order_status] || order.order_status,
      order.delivery_method,
    ].some((value) => String(value || '').toLowerCase().includes(query)))
  }, [filteredOrders, searchQuery])

  // Resets detail notices when another order is selected.
  useEffect(() => {
    setReceiptError('')
    setShowFullProgress(false)
    setShowPreCancelDetails(false)
  }, [selectedOrderId])

  // Confirms receipt of the selected delivery.
  async function handleConfirmReceipt() {
    if (!selectedOrder) return
    setConfirming(true)
    setReceiptError('')
    try {
      const updatedOrder = await confirmBuyerOrderReceipt(selectedOrder.id)
      setOrders((current) => current.map((order) => (order.id === updatedOrder.id ? updatedOrder : order)))
    } catch (requestError) {
      setReceiptError(requestError.message)
    } finally {
      setConfirming(false)
    }
  }

  // Confirms receipt from the order list.
  async function handleListConfirmReceipt(order) {
    setConfirmingOrderId(order.id); setReceiptError('')
    try { const updated = await confirmBuyerOrderReceipt(order.id); setOrders((current) => current.map((item) => item.id === updated.id ? updated : item)) }
    catch (requestError) { setReceiptError(requestError.message) }
    finally { setConfirmingOrderId(null) }
  }

  // Opens the cancellation form for an order.
  function openCancelModal(order) {
    setCancelTarget(order)
    setCancelReason('')
    setCancelNote('')
    setCancelError('')
  }

  // Closes and resets the cancellation form.
  function closeCancelModal() {
    if (cancelling) return
    setCancelTarget(null)
  }

  // Sends an order cancellation request.
  async function handleCancelOrder(event) {
    event.preventDefault()
    if (!cancelTarget || !cancelReason) return
    if (cancelReason === 'other' && !cancelNote.trim()) { setCancelError('Enter a cancellation reason.'); return }
    setCancelling(true)
    setCancelError('')
    try {
      const updated = await cancelBuyerOrder(cancelTarget.id, { category: cancelReason, note: cancelNote })
      setOrders((current) => current.map((order) => (order.id === updated.id ? updated : order)))
      setCancelTarget(null)
    } catch (requestError) {
      setCancelError(requestError.message)
    } finally {
      setCancelling(false)
    }
  }

  // The cart page re-checks every saved item against live stock, so only ids and quantities are needed here.
  // Adds an order's products to the cart again.
  function handleBuyAgain(order) {
    const merged = new Map(readBuyerCart().map((item) => [String(item.id), { ...item }]))
    order.items.forEach((item) => {
      if (!item.pineapple_size_id) return
      const existing = merged.get(String(item.pineapple_size_id))
      if (existing) existing.quantity = (Number(existing.quantity) || 0) + item.quantity
      else merged.set(String(item.pineapple_size_id), { id: item.pineapple_size_id, quantity: item.quantity })
    })
    writeBuyerCart([...merged.values()])
    window.location.href = '/buyer/cart'
  }

  // initialValue lets a click on a star in the order card open the window with that star already chosen.
  // Opens the rating form for a completed order.
  function openRateModal(order, initialValue = order.buyer_rating || 0) {
    setRateTarget(order)
    setRateValue(initialValue)
    setRateHoverValue(0)
    setRateComment(order.buyer_rating_comment || '')
    setRateError('')
    setRateSubmitted(false)
  }

  // Closes and resets the rating form.
  function closeRateModal() {
    if (rateSubmitting) return
    setRateTarget(null)
  }

  // Saves a buyer rating for the order.
  async function handleSubmitRating(event) {
    event.preventDefault()
    if (!rateTarget || !rateValue) return
    setRateSubmitting(true)
    setRateError('')
    try {
      const updated = await rateBuyerOrder(rateTarget.id, rateValue, rateComment)
      setOrders((current) => current.map((order) => (order.id === updated.id ? updated : order)))
      setRateSubmitted(true)
    } catch (requestError) {
      setRateError(requestError.message)
    } finally {
      setRateSubmitting(false)
    }
  }

  const milestones = selectedOrder ? createMilestones(selectedOrder) : []
  const destination = selectedOrder ? getDeliveryAddress(selectedOrder) : { primary: '', secondary: '' }
  const collapsible = selectedOrder ? canCollapseProgress(selectedOrder) : false
  const progressCollapsed = collapsible && !showFullProgress
  const progressSummaryText = progressCollapsed ? progressSummary(selectedOrder) : null

  return (
    <main className="buyer-page delivery-page">
      {/* Marketplace navigation and order tracking. */}
      <BuyerHeader active="orders" cartCount={buyerCartQuantity(readBuyerCart())} />

      <div className="delivery-content">
        {selectedOrder && (
          <button
            className="delivery-back-button"
            type="button"
            onClick={() => {
              // Arriving from a tracking link (?track=) has no list state to fall back to, so reload the list page.
              if (trackedOrderId) { window.location.href = '/buyer/delivery-progress'; return }
              setSelectedOrderId(null)
              window.scrollTo({ top: 0, behavior: 'smooth' })
            }}
          >
            <ChevronLeft aria-hidden="true" /> Back
          </button>
        )}

        {/* The cancelled receipt page carries its own centred title. */}
        {(!selectedOrder || !(selectedOrder.order_status === 'cancelled' && !showPreCancelDetails)) && (
          <header className={`delivery-title ${selectedOrder ? 'is-order' : ''}`}>
            {!selectedOrder && (
              <div>
                <h1>My Orders</h1>
                <p>Select an order to view its delivery progress and complete details.</p>
              </div>
            )}
            {selectedOrder && <h1>Order {selectedOrder.order_number}</h1>}
          </header>
        )}

        {!selectedOrder && (
          <>
            {/* Filters for the buyer's order history. */}
            <nav className="buyer-order-tabs" aria-label="Filter orders by status">
              {ORDER_FILTERS.map((filter) => (
                <button
                  key={filter.id}
                  type="button"
                  className={activeFilter === filter.id ? 'is-active' : ''}
                  aria-pressed={activeFilter === filter.id}
                  onClick={() => setActiveFilter(filter.id)}
                >
                  <span>{filter.label}</span>
                </button>
              ))}
            </nav>

          </>
        )}

        {error && <div className="delivery-message is-error" role="alert"><span>{error}</span><button type="button" onClick={fetchOrders}>Try again</button></div>}
        {loading && <div className="delivery-message" role="status">Loading your orders…</div>}
        {!loading && !error && orders.length === 0 && <section className="delivery-card delivery-empty">
          <PackageCheck aria-hidden="true" />
          <h2>No orders yet</h2>
          <p>Your delivery progress will appear here after checkout.</p>
          <a href="/buyer/order">Place Your First Order</a>
        </section>}

        {!loading && !error && orders.length > 0 && filteredOrders.length === 0 && !selectedOrder && (
          <section className="delivery-card delivery-empty delivery-filter-empty">
            <PackageOpen aria-hidden="true" />
            <h2>No orders in this category</h2>
            <p>Orders matching this status will appear here.</p>
            <button type="button" onClick={() => setActiveFilter('all')}>View All Orders</button>
          </section>
        )}

        {/* Orders matching the selected filters. */}
        {!loading && !error && filteredOrders.length > 0 && !selectedOrder && (
          <section className="delivery-card order-history is-history-view" aria-labelledby="order-history-title">
            <header className="history-heading">
              <div><h2 id="order-history-title">{activeFilter === 'all' ? 'Order History' : ORDER_FILTERS.find((filter) => filter.id === activeFilter)?.label}</h2><p>{visibleOrders.length} order{visibleOrders.length === 1 ? '' : 's'} in this view</p></div>
              <label className="order-history-search">
                <span className="sr-only">Search your orders</span>
                <Search aria-hidden="true" />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(event) => setSearchQuery(event.target.value)}
                  placeholder="Search order number or item"
                />
              </label>
            </header>
            <div className="history-list">
              <div className="history-list-head" aria-hidden="true"><span>Order</span><span>Items</span><span>Total</span><span>Actions</span></div>
              {visibleOrders.length === 0 && (
                <div className="history-search-empty">
                  <Search aria-hidden="true" />
                  <p>No orders match “{searchQuery.trim()}”.</p>
                  <button type="button" onClick={() => setSearchQuery('')}>Clear Search</button>
                </div>
              )}
              {visibleOrders.map((order) => (
                <article
                  className="history-order"
                  key={order.id}
                  role="button"
                  tabIndex="0"
                  onClick={() => { setSelectedOrderId(order.id); window.scrollTo({ top: 0, behavior: 'smooth' }) }}
                  onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); setSelectedOrderId(order.id); window.scrollTo({ top: 0, behavior: 'smooth' }) } }}
                >
                  <div className="history-copy">
                    <small>{order.order_number}</small>
                    <time>{formatDate(order.created_at)}</time>
                  </div>
                  <p className="history-items">{orderItemsText(order)}</p>
                  <div className="history-payment"><strong>PHP {Number(order.total_amount || 0).toLocaleString()}</strong><small>{String(order.delivery_method || 'Delivery').replaceAll('_', ' ')}</small></div>
                  <div className="history-order-actions">
                    {activeFilter === 'returns' ? (
                      <span className="history-view-order">View details <ChevronRight aria-hidden="true" /></span>
                    ) : (<>
                    {(order.order_status === 'delivered' || order.order_status === 'completed') && !order.delivery_dispute_status && <button type="button" onClick={(event) => { event.stopPropagation(); window.location.href = `/buyer/return-request?order=${order.id}` }}>{order.order_status === 'delivered' ? 'Report an Issue' : 'Return/Refund'}</button>}
                    {order.order_status === 'delivered' && !order.delivery_dispute_status && <button type="button" className="is-primary" disabled={confirmingOrderId === order.id} onClick={(event) => { event.stopPropagation(); handleListConfirmReceipt(order) }}>{confirmingOrderId === order.id ? 'Confirming…' : 'Order Received'}</button>}
                    {order.order_status === 'completed' && !order.buyer_rating && <button type="button" className="is-primary" onClick={(event) => { event.stopPropagation(); openRateModal(order) }}>Rate</button>}
                    {order.payment_method === 'gcash' && needsPayment(order) && <button type="button" className="is-primary" onClick={(event) => { event.stopPropagation(); window.location.href = `/buyer/payment-confirmation?order=${encodeURIComponent(order.id)}` }}>Pay with GCash</button>}
                    {canCancelOrder(order) && <button type="button" className="is-danger" onClick={(event) => { event.stopPropagation(); openCancelModal(order) }}>Cancel order</button>}
                    {!['delivered', 'completed'].includes(order.order_status) && <span className="history-view-order">View details <ChevronRight aria-hidden="true" /></span>}
                    </>)}
                  </div>
                </article>
              ))}
            </div>
          </section>
        )}

        {selectedOrder && <>
          {selectedOrder.delivery_dispute_status && (
            <section
              className={`delivery-card delivery-return-formal-card is-${selectedOrder.delivery_dispute_status}`}
              aria-labelledby="delivery-return-status-title"
              role="button"
              tabIndex={0}
              onClick={() => {
                window.location.href = `/buyer/return-details?order=${selectedOrder.id}`
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault()
                  window.location.href = `/buyer/return-details?order=${selectedOrder.id}`
                }
              }}
            >
              <div className="delivery-return-formal-top">
                <div className="delivery-return-formal-left">
                  <span className="delivery-return-formal-icon" aria-hidden="true">
                    <PackageOpen />
                  </span>
                  <div className="delivery-return-formal-headings">
                    <h2 id="delivery-return-status-title">
                      {selectedOrder.delivery_dispute_status === 'open'
                        ? 'We’re reviewing your return request'
                        : 'Update on your return request'}
                    </h2>
                    <p>
                      {disputeCategoryLabels[selectedOrder.delivery_dispute_category] || 'Damaged produce'}
                      {selectedOrder.delivery_dispute_affected_quantity
                        ? ` · ${selectedOrder.delivery_dispute_affected_quantity} affected`
                        : ''}
                      {Array.isArray(selectedOrder.delivery_dispute_photo_urls) && selectedOrder.delivery_dispute_photo_urls.length > 0
                        ? ` · ${selectedOrder.delivery_dispute_photo_urls.length} photo${selectedOrder.delivery_dispute_photo_urls.length > 1 ? 's' : ''} attached`
                        : ''}
                    </p>
                  </div>
                </div>

                <div className="delivery-return-formal-right">
                  <span className="delivery-return-view-btn">View details</span>
                </div>
              </div>

              <div className="delivery-return-formal-divider" />

              <ProgressStepper steps={buildReturnSteps(selectedOrder, formatShortDate)} />
              <ReturnDecision order={selectedOrder} compact />
            </section>
          )}

          {selectedOrder.order_status === 'cancelled' && !showPreCancelDetails ? (
          <div className="cancelled-receipt">
            <header className="delivery-title">
              <h1>Order {selectedOrder.order_number}</h1>
            </header>

            <section className="delivery-card cancelled-summary" aria-labelledby="cancelled-title">
              <span className="cancelled-hero-icon" aria-hidden="true"><X /></span>
              <h2 id="cancelled-title">Order cancelled</h2>
              <p className="cancelled-when">{selectedOrder.cancelled_at ? formatDate(selectedOrder.cancelled_at, true) : 'Cancellation time unavailable'} · {selectedOrder.order_number}</p>
              <dl className="cancelled-facts">
                <div><dt>Reason</dt><dd>{selectedOrder.cancellation_reason || 'Not specified'}</dd></div>
                <div><dt>Payment</dt><dd>{PAYMENT_METHOD_LABELS[selectedOrder.payment_method] || selectedOrder.payment_method}</dd></div>
                <div><dt>Placed</dt><dd>{formatDate(selectedOrder.created_at, true)}</dd></div>
                {selectedOrder.refund_amount != null && (
                  <div><dt>Refund</dt><dd>PHP {Number(selectedOrder.refund_amount).toLocaleString()} · {{ requested: 'Awaiting admin review', submitting: 'Submitting to PayMongo', processing: 'Processing', succeeded: 'Processed', failed: 'Needs review', review_required: 'Needs review', rejected: 'Not approved' }[selectedOrder.refund_status] || 'Awaiting review'}</dd></div>
                )}
              </dl>
              {selectedOrder.refund_amount != null && (
                <p className="cancelled-refund-note">{selectedOrder.refund_status === 'succeeded' ? 'PayMongo processed this refund. Your bank or wallet may take additional time to show it.' : selectedOrder.refund_status === 'rejected' ? (selectedOrder.refund_decision_notes || 'The admin did not approve this refund request.') : selectedOrder.refund_status === 'failed' || selectedOrder.refund_status === 'review_required' ? 'The admin is checking this refund with PayMongo.' : qrphRefundLink(selectedOrder) ? 'PayMongo is waiting for you to claim this QR Ph refund. The transfer link expires after 3 days.' : selectedOrder.refund_status === 'processing' ? 'PayMongo is processing your refund.' : 'The admin will review this refund request.'}</p>
              )}
              {qrphRefundLink(selectedOrder) && <p className="cancelled-refund-note"><a href={qrphRefundLink(selectedOrder)} target="_blank" rel="noopener noreferrer">Open refund claim link</a></p>}
            </section>

            <section className="delivery-card cancelled-items" aria-labelledby="cancelled-items-title">
              <h2 id="cancelled-items-title">Items</h2>
              <div className="cancelled-items-head" aria-hidden="true"><span /><span>Item</span><span>Qty</span><span>Price</span></div>
              {selectedOrder.items.map((item) => (
                <div className="cancelled-item" key={item.id}>
                  <img src={pineappleImage} alt="" />
                  <p><strong>{item.product_name}</strong><small>{item.weight_label}</small></p>
                  <span className="cancelled-item-qty">×{item.quantity}</span>
                  <span className="cancelled-item-price">PHP {item.line_total.toLocaleString()}</span>
                </div>
              ))}
              <div className="cancelled-total-row"><span>Shipping</span><span>PHP {selectedOrder.shipping_fee.toLocaleString()}</span></div>
              <div className="cancelled-total-row is-total"><span>Total</span><span>PHP {selectedOrder.total_amount.toLocaleString()}</span></div>
            </section>

            <div className="cancelled-actions">
              <button type="button" className="order-detail-link-button" onClick={() => { setShowPreCancelDetails(true); window.scrollTo({ top: 0, behavior: 'smooth' }) }}>
                <ReceiptText aria-hidden="true" /> Order details
              </button>

              {selectedOrder.items.some((item) => item.pineapple_size_id) && (
                <button type="button" className="buy-again-button" onClick={() => handleBuyAgain(selectedOrder)}>Buy again</button>
              )}
            </div>
          </div>
          ) : (<>
          {selectedOrder.order_status === 'cancelled' && (
            <button type="button" className="order-detail-link-button is-back" onClick={() => { setShowPreCancelDetails(false); window.scrollTo({ top: 0, behavior: 'smooth' }) }}>
              <ChevronLeft aria-hidden="true" /> Back to cancellation
            </button>
          )}
          <div className="order-detail-layout">
          <div className="order-detail-main">
          <section
            className={`delivery-card delivery-route ${progressCollapsed ? 'is-collapsed' : ''}`}
            aria-label={progressCollapsed ? 'Order progress' : undefined}
            aria-labelledby={progressCollapsed ? undefined : 'delivery-route-title'}
          >
            {progressCollapsed ? (
              <div className="progress-summary">
                <span className="progress-summary-icon" aria-hidden="true"><Check /></span>
                <div>
                  <strong>{progressSummaryText.headline}</strong>
                  {progressSummaryText.detail && <small>{progressSummaryText.detail}</small>}
                </div>
                <button type="button" className="progress-summary-toggle" onClick={() => setShowFullProgress(true)}>View full progress</button>
              </div>
            ) : <>
            <div className="delivery-route-heading">
              <h2 id="delivery-route-title">{selectedOrder.delivery_method === 'pickup' ? 'Pickup Progress' : 'Delivery Route'}</h2>
              {collapsible && <button type="button" className="progress-summary-toggle" onClick={() => setShowFullProgress(false)}>Hide progress</button>}
            </div>
            {selectedOrder.delivery_method !== 'pickup' && (
              <div className="route-map">
                <article className="route-location route-origin">
                  <span className="route-location-label"><Store aria-hidden="true" /> From</span>
                  <strong className="route-location-main">JToledo Trading Farm</strong>
                  <span className="route-location-sub">Tagaytay City</span>
                </article>
                <span className="route-dashes" aria-hidden="true" />
                <IconBadge icon={Truck} />
                <span className="route-dashes" aria-hidden="true" />
                <article className="route-location route-destination">
                  <span className="route-location-label"><MapPin aria-hidden="true" /> Deliver to</span>
                  <strong className="route-location-main">{destination.primary || 'Address not provided'}</strong>
                  {destination.secondary && <span className="route-location-sub">{destination.secondary}</span>}
                </article>
              </div>
            )}

            <ProgressStepper
              steps={milestones.map(({ label, date, icon, complete, current, estimated }) => ({
                icon,
                label,
                sub: date ? `${estimated && !complete && !current ? 'Est. ' : ''}${formatShortDate(date)}` : 'Pending',
                state: complete ? 'done' : current ? 'current' : '',
              }))}
            />
            </>}
          </section>

            {/* Products in the selected order. */}
            <section className="delivery-card order-items" aria-labelledby="order-items-title">
              <h2 id="order-items-title">Order Items</h2>
              <div className="order-item-list">
                {selectedOrder.items.map((item) => (
                  <article className="delivery-order-item" key={item.id}>
                    <img src={pineappleImage} alt="" />
                    <p><strong>{item.product_name}</strong><span>{item.weight_label} · {item.quantity} {item.quantity === 1 ? 'piece' : 'pieces'}</span><b>PHP {item.line_total.toLocaleString()}</b></p>
                  </article>
                ))}
              </div>
              <div className="delivery-order-cost"><span>Shipping</span><strong>PHP {selectedOrder.shipping_fee.toLocaleString()}</strong></div>
              <div className="delivery-total"><span>Total</span><strong>PHP {selectedOrder.total_amount.toLocaleString()}</strong></div>
            </section>

          </div>

          {/* Status, payment, and delivery actions. */}
          <aside className="order-detail-side">
            {selectedOrder.order_status === 'ready_for_pickup' && (
              <section className="delivery-card pickup-ticket" aria-labelledby="pickup-ticket-title">
                <div className="pickup-ticket-row">
                  <div>
                    <span className="pickup-ticket-label">Order number</span>
                    <h2 id="pickup-ticket-title" className="pickup-ticket-code">{selectedOrder.order_number}</h2>
                    <p>Show this order number to farm staff when you arrive. No need to wait for a courier — collect it whenever the farm is open.</p>
                  </div>
                </div>
                <div className="pickup-ticket-meta">
                  <div className="pickup-ticket-meta-row"><Store aria-hidden="true" /><div><strong>JToledo Trading Farm</strong><span>Tagaytay City, Cavite</span></div></div>
                  <div className="pickup-ticket-meta-row"><CalendarDays aria-hidden="true" /><div><strong>Pickup hours</strong><span>Mon – Sat, 8:00 AM – 5:00 PM</span></div></div>
                </div>
                <a
                  className="pickup-directions-btn"
                  href="https://www.google.com/maps/search/?api=1&query=JToledo+Trading+Farm+Tagaytay+City"
                  target="_blank"
                  rel="noreferrer"
                >
                  <MapPin aria-hidden="true" /> Get Directions
                </a>
              </section>
            )}

            <section className="delivery-card order-details" aria-labelledby="order-details-title">
              <h2 id="order-details-title">Order Details</h2>
              <div className="order-detail-list">
                <article className="order-detail"><IconBadge icon={ReceiptText} /><p><strong>Order Number</strong><span>{selectedOrder.order_number}</span></p></article>
                <article className="order-detail"><IconBadge icon={CalendarDays} /><p><strong>Order Date</strong><span>{formatDate(selectedOrder.created_at, true)}</span></p></article>
                <article className="order-detail"><IconBadge icon={Truck} /><p><strong>Est. Delivery</strong><span>{selectedOrder.delivery_method === 'pickup' ? 'On-site pickup' : formatDate(selectedOrder.estimated_delivery_at)}</span></p></article>
              </div>

              {selectedOrder.delivery_proof_image_url && (
                <div className="order-delivery-proof">
                  <span className="order-delivery-proof-label">
                    <Camera size={15} />
                    Proof of delivery
                  </span>

                  <button
                    type="button"
                    className="order-delivery-proof-photo"
                    onClick={() => setViewingDeliveryProof(true)}
                    aria-label="View full proof of delivery photo"
                  >
                    <img src={selectedOrder.delivery_proof_image_url} alt="Proof of delivery" />
                    <span className="order-delivery-proof-zoom" aria-hidden="true">
                      <Maximize2 size={14} />
                    </span>
                  </button>

                  {selectedOrder.delivery_proof_notes && (
                    <p className="order-delivery-proof-note"><strong>Driver note:</strong> “{selectedOrder.delivery_proof_notes}”</p>
                  )}
                </div>
              )}
            </section>

            {selectedOrder.order_status === 'completed' && !isReturnOrRefund(selectedOrder) && (
              <section className="delivery-card delivery-rate-card" aria-labelledby="delivery-rate-title">
                <div className="delivery-rate-text">
                  <h2 id="delivery-rate-title">{selectedOrder.buyer_rating ? 'Your rating' : 'How was your order?'}</h2>
                  <p>{selectedOrder.buyer_rating ? 'Thanks for rating your order.' : 'Tap a star to rate — it helps other buyers and the farm.'}</p>
                </div>
                <div className="delivery-rate-actions">
                  {selectedOrder.buyer_rating ? (
                    <StarRating value={selectedOrder.buyer_rating} size={26} />
                  ) : (
                    <StarRating
                      value={rateCardHover}
                      size={26}
                      interactive
                      onHover={setRateCardHover}
                      onSelect={(stars) => { setRateCardHover(0); openRateModal(selectedOrder, stars) }}
                    />
                  )}
                </div>
              </section>
            )}

            {selectedOrder.payment_method === 'gcash' && needsPayment(selectedOrder) && (
              <section className="delivery-card delivery-confirmation" aria-labelledby="delivery-payment-title">
                <h2 id="delivery-payment-title">GCash payment {selectedOrder.payment_status === 'failed' ? 'unsuccessful' : 'not confirmed'}</h2>
                <p>Your order is saved. Check the payment status or continue paying with GCash.</p>
                <div className="delivery-confirmation-actions">
                  <button type="button" className="is-primary" onClick={() => { window.location.href = `/buyer/payment-confirmation?order=${encodeURIComponent(selectedOrder.id)}` }}>Check or Retry Payment</button>
                </div>
              </section>
            )}

            {canCancelOrder(selectedOrder) && (
              <section className="delivery-card delivery-confirmation delivery-cancel-card" aria-labelledby="delivery-cancel-title">
                <h2 id="delivery-cancel-title">Need to cancel this order?</h2>
                <p>
                  This order hasn't started preparing yet, so you can still cancel it
                  {['gcash', 'qrph'].includes(selectedOrder.payment_method) && selectedOrder.payment_status === 'paid' ? ' and request a refund of the payment.' : '.'}
                </p>
                <div className="delivery-confirmation-actions">
                  <button type="button" className="is-danger" onClick={() => openCancelModal(selectedOrder)}>Cancel Order</button>
                </div>
              </section>
            )}

            {selectedOrder.order_status === 'delivered' && selectedOrder.delivery_dispute_status !== 'open' && (
              <section className="delivery-card delivery-confirmation delivery-receipt-card" aria-labelledby="delivery-confirmation-title">
                <h2 id="delivery-confirmation-title">Did you receive your order?</h2>
                <p>Confirm everything arrived as expected, or report a problem while the delivery details are still fresh.</p>
                {receiptError && <div className="delivery-message is-error" role="alert">{receiptError}</div>}
                <div className="delivery-confirmation-actions">
                  <button type="button" className="is-primary" onClick={handleConfirmReceipt} disabled={confirming}>
                    {confirming ? 'Confirming…' : 'Confirm Receipt'}
                  </button>
                  <button type="button" className="is-secondary" onClick={() => { window.location.href = `/buyer/return-request?order=${selectedOrder.id}` }} disabled={confirming}>
                    Report an Issue
                  </button>
                </div>
              </section>
            )}

            {selectedOrder.order_status === 'completed' && !isReturnOrRefund(selectedOrder) && (
              <p className="order-report-note">
                <button type="button" className="order-report-link" onClick={() => { window.location.href = `/buyer/return-request?order=${selectedOrder.id}` }}>
                  Noticed something wrong? Report an issue
                </button>
              </p>
            )}
          </aside>
          </div>
          </>)}

        </>}
      </div>

      {/* Form for cancelling an eligible order. */}
      {cancelTarget && (
        <div className="cancel-modal-overlay" onClick={closeCancelModal}>
          <form className="cancel-modal" onClick={(event) => event.stopPropagation()} onSubmit={handleCancelOrder}>
            <div className="cancel-modal-icon"><XCircle aria-hidden="true" /></div>
            <h3>Cancel Order</h3>

            <div className="cancel-modal-summary">
              <div>
                <strong>{cancelTarget.order_number}</strong>
                <span>{orderItemsText(cancelTarget)}</span>
              </div>
              <b>PHP {Number(cancelTarget.total_amount || 0).toLocaleString()}</b>
            </div>

            <fieldset className="cancel-modal-reasons">
              <legend>Reason for cancellation</legend>
              {CANCEL_REASONS.map((reasonOption) => (
                <label key={reasonOption.value}>
                  <input
                    type="radio"
                    name="cancel-reason"
                    value={reasonOption.value}
                    checked={cancelReason === reasonOption.value}
                    onChange={(event) => setCancelReason(event.target.value)}
                  />
                  <span>{reasonOption.label}</span>
                </label>
              ))}
              {cancelReason === 'other' && (
                <textarea
                  value={cancelNote}
                  onChange={(event) => setCancelNote(event.target.value)}
                  placeholder="Enter the reason"
                  maxLength={500}
                />
              )}
            </fieldset>

            {cancelError && <div className="delivery-message is-error" role="alert">{cancelError}</div>}

            <div className="delivery-confirmation-actions cancel-modal-actions">
              <button type="button" className="is-secondary" onClick={closeCancelModal} disabled={cancelling}>Keep Order</button>
              <button type="submit" className="is-danger" disabled={!cancelReason || cancelling}>
                {cancelling ? 'Cancelling…' : 'Confirm Cancellation'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Form for rating a completed order. */}
      {rateTarget && (
        <div className="rate-modal-overlay" onClick={closeRateModal}>
          {rateSubmitted ? (
            <div className="rate-modal" onClick={(event) => event.stopPropagation()}>
              <div className="rate-success">
                <div className="rate-success-icon"><Check aria-hidden="true" /></div>
                <h3>Thanks for rating!</h3>
                <p>Your feedback helps other buyers and the farm.</p>
                <button type="button" className="is-primary" onClick={closeRateModal}>Done</button>
              </div>
            </div>
          ) : (
            <form className="rate-modal" onClick={(event) => event.stopPropagation()} onSubmit={handleSubmitRating}>
              <div className="rate-modal-eyebrow">Order {rateTarget.order_number}</div>
              <h3>Rate your purchase</h3>
              <p>How was your order of {orderItemsText(rateTarget)}?</p>

              <StarRating
                value={rateHoverValue || rateValue}
                size={34}
                interactive
                onHover={setRateHoverValue}
                onSelect={setRateValue}
              />
              <div className="rate-modal-star-label">{RATING_LABELS[rateHoverValue || rateValue] || ' '}</div>

              <textarea
                value={rateComment}
                onChange={(event) => setRateComment(event.target.value)}
                placeholder="Share your experience (optional)"
                maxLength={500}
              />
              <div className="rate-modal-count">{rateComment.length}/500</div>

              {rateError && <div className="delivery-message is-error" role="alert">{rateError}</div>}

              <div className="delivery-confirmation-actions cancel-modal-actions">
                <button type="button" className="is-secondary" onClick={closeRateModal} disabled={rateSubmitting}>Maybe later</button>
                <button type="submit" className="is-primary" disabled={!rateValue || rateSubmitting}>
                  {rateSubmitting ? 'Submitting…' : 'Submit rating'}
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* Full-size proof of delivery photo. */}
      {viewingDeliveryProof && selectedOrder?.delivery_proof_image_url && (
        <div className="return-lightbox-overlay" onClick={() => setViewingDeliveryProof(false)}>
          <div className="return-lightbox-content" onClick={(e) => e.stopPropagation()}>
            <button
              type="button"
              className="return-lightbox-close"
              onClick={() => setViewingDeliveryProof(false)}
              aria-label="Close photo preview"
            >
              <X size={18} />
            </button>
            <img src={selectedOrder.delivery_proof_image_url} alt="Proof of delivery" />
            {selectedOrder.delivery_proof_notes && (
              <div className="order-delivery-proof-lightbox-caption">
                <p><strong>Driver note:</strong> {selectedOrder.delivery_proof_notes}</p>
              </div>
            )}
          </div>
        </div>
      )}

      <BuyerFooter />
    </main>
  )
}
