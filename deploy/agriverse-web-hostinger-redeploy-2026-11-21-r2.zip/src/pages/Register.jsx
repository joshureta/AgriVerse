import { useEffect, useRef, useState } from 'react'
import { Eye, EyeOff, MailCheck } from 'lucide-react'
import { useAuth } from '../hooks/useAuth.js'
import { supabase } from '../lib/supabase.js'
import {
  getCityMunicipalityBarangays,
  getProvinceCitiesMunicipalities,
  getRegionCitiesMunicipalities,
  getRegionProvinces,
  getRegions,
} from '../services/psgc.js'
import jtoledoLogo from '../assets/Jtoledologo.png'
import AuthHero from '../components/AuthHero.jsx'
import '../styles/register.css'

const VERIFICATION_CODE_LENGTH = 6
// Creates a blank set of email verification code inputs.
const emptyVerificationDigits = () => Array(VERIFICATION_CODE_LENGTH).fill('')

// Renders a registration input with optional password visibility control.
function Field({
  autoComplete,
  disabled,
  label,
  name,
  onChange,
  placeholder,
  type = 'text',
}) {
  const [showPassword, setShowPassword] = useState(false)
  const isPassword = type === 'password'

  return (
    <label className="register-field">
      <span>{label}</span>
      <div className={isPassword ? 'register-input-shell' : undefined}>
        <input
          name={name}
          type={isPassword && showPassword ? 'text' : type}
          autoComplete={autoComplete}
          placeholder={placeholder}
          disabled={disabled}
          onChange={onChange}
          required
        />
        {isPassword && (
          <button
            className="register-password-toggle"
            type="button"
            onClick={() => setShowPassword((visible) => !visible)}
            aria-label={showPassword ? `Hide ${label.toLowerCase()}` : `Show ${label.toLowerCase()}`}
            aria-pressed={showPassword}
            disabled={disabled}
          >
            {showPassword ? <EyeOff size={20} aria-hidden="true" /> : <Eye size={20} aria-hidden="true" />}
          </button>
        )}
      </div>
    </label>
  )
}

// Renders a required address selector from location options.
function SelectField({
  disabled,
  label,
  name,
  onChange,
  options,
  placeholder,
  value,
}) {
  return (
    <label className="register-field">
      <span>{label}</span>
      <select
        name={name}
        value={value}
        onChange={onChange}
        disabled={disabled}
        required
      >
        <option value="">{placeholder}</option>
        {options.map((option) => (
          <option key={option.code} value={option.code}>
            {option.name}
          </option>
        ))}
      </select>
    </label>
  )
}

// Guides buyer signup through details, address selection, and email verification.
export default function Register() {
  const { loading: sessionLoading, user } = useAuth()
  const formRef = useRef(null)
  const codeInputRefs = useRef([])
  const [currentStep, setCurrentStep] = useState(0)
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [pendingEmail, setPendingEmail] = useState(
    () => window.sessionStorage.getItem('agriverse-pending-signup-email') || '',
  )
  const [verificationDigits, setVerificationDigits] = useState(emptyVerificationDigits)
  const [resendSeconds, setResendSeconds] = useState(0)
  const [passwordValue, setPasswordValue] = useState('')
  const [confirmPasswordValue, setConfirmPasswordValue] = useState('')
  const [addressError, setAddressError] = useState('')
  const [regions, setRegions] = useState([])
  const [provinces, setProvinces] = useState([])
  const [citiesMunicipalities, setCitiesMunicipalities] = useState([])
  const [barangays, setBarangays] = useState([])
  const [regionCode, setRegionCode] = useState('')
  const [provinceCode, setProvinceCode] = useState('')
  const [cityMunicipalityCode, setCityMunicipalityCode] = useState('')
  const [barangayCode, setBarangayCode] = useState('')
  const [loadingRegions, setLoadingRegions] = useState(true)
  const [loadingProvinces, setLoadingProvinces] = useState(false)
  const [loadingCities, setLoadingCities] = useState(false)
  const [loadingBarangays, setLoadingBarangays] = useState(false)
  const provinceNotApplicable = regionCode && !loadingProvinces && provinces.length === 0
  const passwordChecks = [
    { label: '8+ characters', met: passwordValue.length >= 8 },
    { label: '1 uppercase letter', met: /[A-Z]/.test(passwordValue) },
    { label: '1 number', met: /\d/.test(passwordValue) },
    { label: '1 special character', met: /[^A-Za-z0-9]/.test(passwordValue) },
  ]
  const passwordScore = passwordChecks.filter((check) => check.met).length
  const registrationSteps = ['Personal info', 'Security', 'Location']

  // Sends signed-in users to the marketplace.
  useEffect(() => {
    if (!sessionLoading && user) {
      window.sessionStorage.removeItem('agriverse-pending-signup-email')
      window.location.replace('/buyer')
    }
  }, [sessionLoading, user])

  // Counts down until another verification code can be requested.
  useEffect(() => {
    if (resendSeconds <= 0) return undefined
    const timer = window.setTimeout(() => setResendSeconds((seconds) => seconds - 1), 1000)
    return () => window.clearTimeout(timer)
  }, [resendSeconds])

  // Loads the available regions for the address form.
  useEffect(() => {
    let active = true

    getRegions()
      .then((items) => {
        if (active) {
          setRegions(items)
          setAddressError('')
        }
      })
      .catch((loadError) => {
        if (active) {
          setAddressError(loadError.message)
        }
      })
      .finally(() => {
        if (active) {
          setLoadingRegions(false)
        }
      })

    return () => {
      active = false
    }
  }, [])

  // Resets dependent address fields and loads provinces for the region.
  useEffect(() => {
    let active = true

    setProvinceCode('')
    setCityMunicipalityCode('')
    setBarangayCode('')
    setProvinces([])
    setCitiesMunicipalities([])
    setBarangays([])

    if (!regionCode) {
      return () => {
        active = false
      }
    }

    setLoadingProvinces(true)
    setLoadingCities(true)

    Promise.all([
      getRegionProvinces(regionCode),
      getRegionCitiesMunicipalities(regionCode),
    ])
      .then(([provinceItems, cityItems]) => {
        if (active) {
          setProvinces(provinceItems)
          if (provinceItems.length === 0) {
            setCitiesMunicipalities(cityItems)
          }
          setAddressError('')
        }
      })
      .catch((loadError) => {
        if (active) {
          setAddressError(loadError.message)
        }
      })
      .finally(() => {
        if (active) {
          setLoadingProvinces(false)
          setLoadingCities(false)
        }
      })

    return () => {
      active = false
    }
  }, [regionCode])

  // Loads cities and municipalities after a province is selected.
  useEffect(() => {
    let active = true

    setCityMunicipalityCode('')
    setBarangayCode('')
    setCitiesMunicipalities([])
    setBarangays([])

    if (!provinceCode) {
      return () => {
        active = false
      }
    }

    setLoadingCities(true)
    getProvinceCitiesMunicipalities(provinceCode)
      .then((items) => {
        if (active) {
          setCitiesMunicipalities(items)
          setAddressError('')
        }
      })
      .catch((loadError) => {
        if (active) {
          setAddressError(loadError.message)
        }
      })
      .finally(() => {
        if (active) {
          setLoadingCities(false)
        }
      })

    return () => {
      active = false
    }
  }, [provinceCode])

  // Loads barangays for the selected city or municipality.
  useEffect(() => {
    let active = true

    setBarangayCode('')
    setBarangays([])

    if (!cityMunicipalityCode) {
      return () => {
        active = false
      }
    }

    setLoadingBarangays(true)
    getCityMunicipalityBarangays(cityMunicipalityCode)
      .then((items) => {
        if (active) {
          setBarangays(items)
          setAddressError('')
        }
      })
      .catch((loadError) => {
        if (active) {
          setAddressError(loadError.message)
        }
      })
      .finally(() => {
        if (active) {
          setLoadingBarangays(false)
        }
      })

    return () => {
      active = false
    }
  }, [cityMunicipalityCode])

  // Checks visible fields and password rules before advancing the form.
  function validateCurrentStep() {
    setError('')
    const stepElement = formRef.current?.querySelector(
      `[data-register-step="${currentStep}"]`,
    )
    const fields = Array.from(
      stepElement?.querySelectorAll('input, select') ?? [],
    ).filter((field) => !field.disabled)

    for (const field of fields) {
      if (!field.checkValidity()) {
        field.reportValidity()
        return false
      }
    }

    if (currentStep === 1 && passwordScore < passwordChecks.length) {
      setError('Create a password that meets all four security requirements.')
      return false
    }

    if (currentStep === 1 && passwordValue !== confirmPasswordValue) {
      setError('Passwords do not match.')
      return false
    }

    return true
  }

  // Advances to the next registration step when the current one is valid.
  function handleNextStep() {
    if (validateCurrentStep()) {
      setCurrentStep((step) => Math.min(step + 1, registrationSteps.length - 1))
    }
  }

  // Returns to the previous registration step.
  function handlePreviousStep() {
    setError('')
    setCurrentStep((step) => Math.max(step - 1, 0))
  }

  // Creates the account and starts email verification when needed.
  async function handleSubmit(event) {
    event.preventDefault()
    const formElement = event.currentTarget
    const form = new FormData(formElement)
    const email = form.get('email').trim()
    const password = form.get('password')
    const confirmPassword = form.get('confirmPassword')

    setError('')
    setMessage('')

    if (
      password.length < 8 ||
      !/[A-Z]/.test(password) ||
      !/\d/.test(password) ||
      !/[^A-Za-z0-9]/.test(password)
    ) {
      setError('Create a password that meets all four security requirements.')
      return
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match.')
      return
    }

    const selectedRegion = regions.find((item) => item.code === regionCode)
    const selectedProvince = provinces.find((item) => item.code === provinceCode)
    const selectedCityMunicipality = citiesMunicipalities.find(
      (item) => item.code === cityMunicipalityCode,
    )
    const selectedBarangay = barangays.find((item) => item.code === barangayCode)

    if (!selectedRegion || !selectedCityMunicipality || !selectedBarangay) {
      setError('Complete the guided address fields before creating your account.')
      return
    }

    if (!provinceNotApplicable && !selectedProvince) {
      setError('Select your province before creating your account.')
      return
    }

    setSubmitting(true)

    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: form.get('fullName').trim(),
          mobile_number: form.get('mobileNumber').trim(),
          country: 'Philippines',
          region: selectedRegion.name,
          province: selectedProvince?.name ?? null,
          city_municipality: selectedCityMunicipality.name,
          barangay: selectedBarangay.name,
        },
        emailRedirectTo: `${window.location.origin}/auth/confirm`,
      },
    })

    if (signUpError) {
      setError(signUpError.message)
    } else if (data.session) {
      window.location.replace('/buyer')
    } else {
      formElement.reset()
      setCurrentStep(0)
      setPasswordValue('')
      setConfirmPasswordValue('')
      window.sessionStorage.setItem('agriverse-pending-signup-email', email)
      setPendingEmail(email)
      setVerificationDigits(emptyVerificationDigits())
      setResendSeconds(60)
      setMessage('Code sent. Check your inbox or spam folder.')
    }

    setSubmitting(false)
  }

  // Confirms the emailed code and opens the buyer marketplace.
  async function handleVerifyEmail(event) {
    event.preventDefault()
    if (submitting || verificationDigits.some((digit) => !digit)) return

    setError('')
    setMessage('')
    setSubmitting(true)

    try {
      const { data, error: verifyError } = await supabase.auth.verifyOtp({
        email: pendingEmail,
        token: verificationDigits.join(''),
        type: 'email',
      })

      if (verifyError || !data?.user) {
        setError(verifyError?.message || 'The code could not be verified. Please try again.')
        return
      }

      window.sessionStorage.removeItem('agriverse-pending-signup-email')
      window.location.replace('/buyer')
    } catch {
      setError('Could not verify the code. Check your connection and try again.')
    } finally {
      setSubmitting(false)
    }
  }

  // Requests another signup code after the resend timer expires.
  async function handleResendCode() {
    if (submitting || resendSeconds > 0) return

    setError('')
    setMessage('')
    setSubmitting(true)

    try {
      const { error: resendError } = await supabase.auth.resend({
        type: 'signup',
        email: pendingEmail,
        options: { emailRedirectTo: `${window.location.origin}/auth/confirm` },
      })

      if (resendError) {
        setError(resendError.message)
        return
      }

      setVerificationDigits(emptyVerificationDigits())
      setResendSeconds(60)
      setMessage('New code sent. Check your inbox.')
      codeInputRefs.current[0]?.focus()
    } catch {
      setError('Could not resend the code. Check your connection and try again.')
    } finally {
      setSubmitting(false)
    }
  }

  // Clears pending verification so the buyer can use another email.
  function changeRegistrationEmail() {
    window.sessionStorage.removeItem('agriverse-pending-signup-email')
    setPendingEmail('')
    setVerificationDigits(emptyVerificationDigits())
    setResendSeconds(0)
    setError('')
    setMessage('')
  }

  // Distributes typed digits across the code inputs and moves focus.
  function handleCodeDigitChange(index, value) {
    const digits = value.replace(/\D/g, '')

    setVerificationDigits((current) => {
      const next = [...current]
      if (!digits) {
        next[index] = ''
      } else {
        for (let offset = 0; offset < digits.length && index + offset < VERIFICATION_CODE_LENGTH; offset += 1) {
          next[index + offset] = digits[offset]
        }
      }
      return next
    })

    if (digits) {
      codeInputRefs.current[Math.min(index + digits.length, VERIFICATION_CODE_LENGTH - 1)]?.focus()
    }
  }

  // Fills the verification inputs from a pasted code.
  function handleCodePaste(event) {
    const digits = event.clipboardData.getData('text').replace(/\D/g, '').slice(0, VERIFICATION_CODE_LENGTH)
    if (!digits) return

    event.preventDefault()
    setVerificationDigits(Array.from({ length: VERIFICATION_CODE_LENGTH }, (_, index) => digits[index] || ''))
    codeInputRefs.current[Math.min(digits.length, VERIFICATION_CODE_LENGTH - 1)]?.focus()
  }

  // Moves between code inputs with Backspace and arrow keys.
  function handleCodeKeyDown(event, index) {
    if (event.key === 'Backspace' && !verificationDigits[index] && index > 0) {
      event.preventDefault()
      setVerificationDigits((current) => current.map((digit, digitIndex) => digitIndex === index - 1 ? '' : digit))
      codeInputRefs.current[index - 1]?.focus()
    } else if (event.key === 'ArrowLeft' && index > 0) {
      event.preventDefault()
      codeInputRefs.current[index - 1]?.focus()
    } else if (event.key === 'ArrowRight' && index < VERIFICATION_CODE_LENGTH - 1) {
      event.preventDefault()
      codeInputRefs.current[index + 1]?.focus()
    }
  }

  return (
    <main className="register-page">
      <section className="register-shell" aria-labelledby="register-title">
        <div className="register-form-panel">
          <div className="register-form-wrap">
            <div className="register-brand">
              <img src={jtoledoLogo} alt="Jtoledo Trading" />
            </div>

            <h1 className="register-heading" id="register-title">
              {pendingEmail ? 'Verify your email' : 'Create Account'}
            </h1>
            <p className="register-subtitle">
              {pendingEmail
                ? `Enter the 6-digit code sent to ${pendingEmail}.`
                : 'Complete three quick steps to get started.'}
            </p>

            {pendingEmail ? (
              <form className="register-form" onSubmit={handleVerifyEmail}>
                {error && (
                  <div className="register-alert register-alert-error" role="alert">
                    {error}
                  </div>
                )}
                {message && (
                  <div className="register-alert register-alert-success register-code-notice" role="status">
                    <MailCheck aria-hidden="true" />
                    <span>{message}</span>
                  </div>
                )}
                <div className="register-code-field">
                  <span className="register-code-label" id="register-code-label">Verification code</span>
                  <div className="register-code-inputs" role="group" aria-labelledby="register-code-label" onPaste={handleCodePaste}>
                    {verificationDigits.map((digit, index) => (
                      <input
                        key={index}
                        ref={(element) => { codeInputRefs.current[index] = element }}
                        type="text"
                        inputMode="numeric"
                        autoComplete={index === 0 ? 'one-time-code' : 'off'}
                        aria-label={`Digit ${index + 1} of ${VERIFICATION_CODE_LENGTH}`}
                        maxLength={VERIFICATION_CODE_LENGTH}
                        value={digit}
                        onChange={(event) => handleCodeDigitChange(index, event.target.value)}
                        onKeyDown={(event) => handleCodeKeyDown(event, index)}
                        onFocus={(event) => event.target.select()}
                        disabled={submitting}
                        autoFocus={index === 0}
                      />
                    ))}
                  </div>
                </div>
                <button className="register-button" type="submit" disabled={submitting || verificationDigits.some((digit) => !digit)}>
                  {submitting && <span className="register-spinner" aria-hidden="true" />}
                  <span>{submitting ? 'Verifying…' : 'Verify email'}</span>
                </button>
                <div className="register-verify-actions">
                  <button type="button" onClick={handleResendCode} disabled={submitting || resendSeconds > 0}>
                    {resendSeconds > 0 ? `Resend in ${resendSeconds}s` : 'Resend email'}
                  </button>
                  <button type="button" onClick={changeRegistrationEmail} disabled={submitting}>
                    Use another email
                  </button>
                </div>
              </form>
            ) : (
              <>
            <ol className="register-steps" aria-label="Account creation progress">
              {registrationSteps.map((step, index) => (
                <li
                  key={step}
                  className={[
                    index === currentStep ? 'is-current' : '',
                    index < currentStep ? 'is-complete' : '',
                  ].filter(Boolean).join(' ')}
                  aria-current={index === currentStep ? 'step' : undefined}
                >
                  <span>{index < currentStep ? '✓' : index + 1}</span>
                  <small>{step}</small>
                </li>
              ))}
            </ol>

            <form ref={formRef} className="register-form" onSubmit={handleSubmit}>
              {error && (
                <div className="register-alert register-alert-error" role="alert">
                  {error}
                </div>
              )}
              {message && (
                <div className="register-alert register-alert-success" role="status">
                  {message}
                </div>
              )}

              <fieldset
                className="register-section"
                data-register-step="0"
                hidden={currentStep !== 0}
              >
                <legend>Personal information</legend>
                <div className="register-row">
                  <Field
                    label="Full name"
                    name="fullName"
                    autoComplete="name"
                    placeholder="Enter your full name"
                    disabled={submitting}
                  />
                  <Field
                    label="Email address"
                    name="email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    disabled={submitting}
                  />
                </div>
                <Field
                  label="Mobile number"
                  name="mobileNumber"
                  type="tel"
                  autoComplete="tel"
                  placeholder="+63 900 000 0000"
                  disabled={submitting}
                />
              </fieldset>

              <fieldset
                className="register-section"
                data-register-step="1"
                hidden={currentStep !== 1}
              >
                <legend>Security</legend>
                <div className="register-row">
                  <Field
                    label="Password"
                    name="password"
                    type="password"
                    autoComplete="new-password"
                    placeholder="Create a strong password"
                    disabled={submitting}
                    onChange={(event) => setPasswordValue(event.target.value)}
                  />
                  <Field
                    label="Confirm password"
                    name="confirmPassword"
                    type="password"
                    autoComplete="new-password"
                    placeholder="Repeat password"
                    disabled={submitting}
                    onChange={(event) => setConfirmPasswordValue(event.target.value)}
                  />
                </div>
                {confirmPasswordValue && confirmPasswordValue !== passwordValue && (
                  <p className="register-inline-error" role="alert">
                    Passwords do not match.
                  </p>
                )}
                <div className="register-password-guide" aria-live="polite">
                  <div className="register-strength-bar" aria-hidden="true">
                    {passwordChecks.map((check, index) => (
                      <span
                        key={check.label}
                        className={index < passwordScore ? 'is-met' : ''}
                      />
                    ))}
                  </div>
                  <p>
                    Password strength:{' '}
                    {['Not set', 'Weak', 'Fair', 'Good', 'Strong'][passwordScore]}
                  </p>
                  <ul>
                    {passwordChecks.map((check) => (
                      <li key={check.label} className={check.met ? 'is-met' : ''}>
                        {check.label}
                      </li>
                    ))}
                  </ul>
                </div>
              </fieldset>

              <fieldset
                className="register-section"
                data-register-step="2"
                hidden={currentStep !== 2}
              >
                <legend>Location</legend>
                {addressError && (
                  <div className="register-alert register-alert-error" role="alert">
                    {addressError}
                  </div>
                )}

                <div className="register-row">
                  <label className="register-field">
                    <span>Country</span>
                    <select value="Philippines" disabled>
                      <option value="Philippines">Philippines</option>
                    </select>
                  </label>
                  <SelectField
                    label="Region"
                    name="regionCode"
                    value={regionCode}
                    onChange={(event) => setRegionCode(event.target.value)}
                    options={regions}
                    placeholder={loadingRegions ? 'Loading regions…' : 'Select region'}
                    disabled={loadingRegions || submitting}
                  />
                </div>

                <div className="register-row">
                  {provinceNotApplicable ? (
                    <label className="register-field">
                      <span>Province</span>
                      <select value="not-applicable" disabled>
                        <option value="not-applicable">Not applicable</option>
                      </select>
                    </label>
                  ) : (
                    <SelectField
                      label="Province"
                      name="provinceCode"
                      value={provinceCode}
                      onChange={(event) => setProvinceCode(event.target.value)}
                      options={provinces}
                      placeholder={
                        loadingProvinces ? 'Loading provinces…' : 'Select province'
                      }
                      disabled={!regionCode || loadingProvinces || submitting}
                    />
                  )}
                  <SelectField
                    label="City / Municipality"
                    name="cityMunicipalityCode"
                    value={cityMunicipalityCode}
                    onChange={(event) => setCityMunicipalityCode(event.target.value)}
                    options={citiesMunicipalities}
                    placeholder={
                      loadingCities
                        ? 'Loading cities…'
                        : 'Select city or municipality'
                    }
                    disabled={
                      !regionCode ||
                      (!provinceNotApplicable && !provinceCode) ||
                      loadingCities ||
                      submitting
                    }
                  />
                </div>

                <SelectField
                  label="Barangay"
                  name="barangayCode"
                  value={barangayCode}
                  onChange={(event) => setBarangayCode(event.target.value)}
                  options={barangays}
                  placeholder={
                    loadingBarangays ? 'Loading barangays…' : 'Select barangay'
                  }
                  disabled={!cityMunicipalityCode || loadingBarangays || submitting}
                />
                <label className="register-consent">
                  <input
                    name="termsAccepted"
                    type="checkbox"
                    required
                    disabled={submitting}
                  />
                  <span>
                    I agree to the <strong>Terms of Service</strong> and{' '}
                    <strong>Privacy Policy</strong>.
                  </span>
                </label>
              </fieldset>

              <div className={`register-actions${currentStep === 0 ? ' is-single' : ''}`}>
                {currentStep > 0 && (
                  <button
                    className="register-back"
                    type="button"
                    onClick={handlePreviousStep}
                    disabled={submitting}
                  >
                    Back
                  </button>
                )}

                {currentStep < registrationSteps.length - 1 ? (
                  <button
                    className="register-next"
                    type="button"
                    onClick={handleNextStep}
                    disabled={submitting}
                  >
                    Continue
                  </button>
                ) : (
                  <button
                    className="register-button"
                    type="submit"
                    disabled={submitting}
                  >
                    {submitting && (
                      <span className="register-spinner" aria-hidden="true" />
                    )}
                    <span>{submitting ? 'Creating account…' : 'Sign up'}</span>
                  </button>
                )}
              </div>
            </form>
              </>
            )}

            <p className="register-login">
              Already have an account? <a href="/login">Sign in</a>
            </p>
          </div>
        </div>

        <AuthHero />
      </section>
    </main>
  )
}
